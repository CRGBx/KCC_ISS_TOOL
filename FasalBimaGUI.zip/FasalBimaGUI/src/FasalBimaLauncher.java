


import java.io.IOException;

import javax.swing.SwingUtilities;

import org.crgb.fasalbima.ui.FasalBimaExecution;

public class FasalBimaLauncher {
	public static void main(String[] args)
	{
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				FasalBimaExecution main;
				try {
					main = new FasalBimaExecution();
					main.show();
				} catch (IOException e) {
					e.printStackTrace();
				}
				
			}
		});
	}

}
