package org.crgb.fasalbima.common;



import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility =JsonAutoDetect.Visibility.NONE,setterVisibility = JsonAutoDetect.Visibility.NONE, creatorVisibility =JsonAutoDetect.Visibility.NONE)
public class RequestDto {
	private String authCode;
	private String data;
	public String getClientId() {
		return authCode;
	}
	public void setClientId(String authCode) {
		this.authCode = authCode;
	}
	public String getEncData() {
		return data;
	}
	public void setEncData(String data) {
		this.data = data;
	}
}
