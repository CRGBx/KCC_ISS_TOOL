package org.crgb.fasalbima.common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadPropFile {
	public static Properties readPropertiesFile(String fileName) throws IOException {
		FileInputStream propFile = null;
		Properties prop = null;
		try {
			propFile = new FileInputStream(fileName);
			prop = new Properties();
			prop.load(propFile);
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException ex) {
			ex.printStackTrace();
		} finally {
			propFile.close();
		}
		return prop;
	}

}
