package org.crgb.fasalbima.dbcom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBConnection {
   public  Connection ConnectionString(Properties prop) {
      Connection c = null;
      try {
         Class.forName("org.postgresql.Driver");
         c = DriverManager
            .getConnection("jdbc:postgresql://"+prop.getProperty("db_url")+"/"+prop.getProperty("db_name"),
            		prop.getProperty("db_user"), prop.getProperty("db_pass"));
         
      } catch (Exception e) {
         e.printStackTrace();
         System.err.println(e.getClass().getName()+": "+e.getMessage());
         System.exit(0);
      }
      System.out.println("Opened database successfully");
	return c;
   }
}