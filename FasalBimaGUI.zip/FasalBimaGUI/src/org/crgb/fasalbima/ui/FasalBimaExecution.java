package org.crgb.fasalbima.ui;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.apache.poi.xwpf.usermodel.*;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import org.crgb.fasalbima.dbcom.DBConnection;
import org.crgb.fasalbima.main.*;
import java.awt.Panel;
import java.awt.TextArea;
public class FasalBimaExecution {
	private JFrame window;
	private JTextField textField;
	public FasalBimaExecution() throws IOException {

		initialize();


	}
	private String filePath = System.getProperty("user.dir");
	private JTextField textField_1;


	private void initialize() throws IOException {

		Properties prop = readPropertiesFile(filePath+"\\resources\\config.properties");

		JTabbedPane tp=new JTabbedPane();  
		tp.setSize(900, 600);
		ArrayList<String> pendingList=new ArrayList<>();

		window=new JFrame();
		window.setTitle("Fasal Bima");
		window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		window.setSize(972, 572);
		window.setLocationRelativeTo(null);




		JPanel panel=new JPanel();
		panel.setBackground(new Color(250, 235, 215));
		JPanel panel2=new JPanel();
		panel2.setBackground(new Color(250, 235, 215));
		tp.add("Batch Processing",panel);
		tp.add("Claim Processing",panel2);

		panel.setLayout(null);

		TextArea textArea = new TextArea();
		textArea.setBounds(10, 248, 941, 247);
		panel.add(textArea);

		JLabel lblNewLabel = new JLabel("FY");
		lblNewLabel.setBounds(121, 27, 30, 18);
		panel.add(lblNewLabel);
		//FY Option for Basic Details batch upload
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"2021_2022", "2022_2023"}));
		comboBox.setBounds(161, 22, 133, 29);
		panel.add(comboBox);

		JLabel lblNewLabel_1 = new JLabel("Batch Count");
		lblNewLabel_1.setBounds(328, 24, 84, 24);
		panel.add(lblNewLabel_1);
		//Starting Batch count for Basic details batch upload.
		textField = new JTextField();
		textField.setBounds(409, 22, 133, 29);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Select Type");
		lblNewLabel_2.setBounds(594, 29, 78, 14);
		panel.add(lblNewLabel_2);
		// For selecting the batch upload type
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Crop", "AH"}));
		comboBox_1.setBounds(682, 22, 127, 29);
		panel.add(comboBox_1);

		//For selecting the Claim Type
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"IS", "IS RollOver", "IS and PRI"}));
		comboBox_2.setBounds(170, 37, 97, 29);
		panel2.add(comboBox_2);

		textField_1 = new JTextField();
		textField_1.setBounds(396, 37, 107, 29);
		panel2.add(textField_1);
		textField_1.setColumns(10);
		//Starting Batch count for Claim batch upload.
		TextArea textArea_1 = new TextArea();
		textArea_1.setBounds(10, 247, 931, 247);
		panel2.add(textArea_1);

		JLabel lblNewLabel_3 = new JLabel("Batch Count");
		lblNewLabel_3.setBounds(325, 44, 72, 14);
		panel2.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("Claim Type");
		lblNewLabel_4.setBounds(93, 44, 79, 14);
		panel2.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("FY");
		lblNewLabel_5.setBounds(605, 44, 36, 14);
		panel2.add(lblNewLabel_5);
		//For selecting the Claim Financial Year
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"2022_2023"}));
		comboBox_3.setBounds(651, 37, 135, 29);
		panel2.add(comboBox_3);

		
		//For Uploading the Basic Details batch
		JButton btnNewButton = new JButton("Upload Batch");
		btnNewButton.setBackground(Color.CYAN);
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String fy=comboBox.getSelectedItem().toString();

				if(textField.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null,"Please enter batch count");
				}
				else
				{
					int batchCount=Integer.parseInt( textField.getText());
					String batchType=comboBox_1.getSelectedItem().toString();
					try {
						if(batchType.equals("Crop"))
						{
							BatchSubmit_NewFY sb=new BatchSubmit_NewFY();

							sb.BatchProcessing(prop, fy, batchCount,textArea);
						}
						else
						{
							AnimalAH_NewFY ah=new AnimalAH_NewFY();
							ah.BatchProcessing(prop,fy,batchCount,textArea);
						}

					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}

			}
		});


		btnNewButton.setBounds(96, 85, 179, 37);
		panel.add(btnNewButton);
		
		//For Getting the status of the Uploaded Batches
		JButton btnNewButton_1 = new JButton("Get Batch Status");
		btnNewButton_1.setBackground(Color.CYAN);
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String fy=comboBox.getSelectedItem().toString();
				GetBatchStatus bs=new GetBatchStatus();
				try {

					//textArea.append(fy);
					String statusJson=bs.BatchStatus(prop, fy,textArea);

					JSONParser parser = new JSONParser();  
					System.out.println("==="+statusJson);



					JSONObject json = (JSONObject) parser.parse(statusJson);
					if(json.get("responseCode").equals("200"))
					{
						JOptionPane.showMessageDialog(null,"Batch Status updated successfully!!");
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Something Went Wrong");
					}

				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
			}
		});
		btnNewButton_1.setBounds(388, 85, 179, 37);
		panel.add(btnNewButton_1);

		
		//Download successfully Processed Basic details
		JButton btnNewButton_2 = new JButton("Download Processed List");
		btnNewButton_2.setBackground(Color.CYAN);
		btnNewButton_2.setForeground(Color.BLACK);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String fy=comboBox.getSelectedItem().toString();
				Date dateNow = new Date();

				//change date into string yyyyMMdd format example "20110914"
				SimpleDateFormat dateformatyyyyMMdd = new SimpleDateFormat("ddMMyy");
				String date_to_string = dateformatyyyyMMdd.format(dateNow);

				DBConnection db=new DBConnection();
				Connection c =db.ConnectionString(prop);

				String process_query = "select * from kcc_iss.\"Batch_Processed_"+fy+"\" where \"isDeleted\" isnull and \"Status\"='1' ";

				textArea.append(process_query);

				textArea.append("\nFile Download is in process...");
				Workbook workbook = new XSSFWorkbook();

				XSSFCellStyle style1 = (XSSFCellStyle) workbook.createCellStyle();
				XSSFFont my_font=(XSSFFont) workbook.createFont();
				my_font.setBold(true);
				style1.setFont(my_font);


				XSSFSheet sheet = (XSSFSheet) workbook.createSheet("processed_batch");
				XSSFFont font = (XSSFFont) workbook.createFont();
				XSSFRow header = sheet.createRow(0);

				header.createCell(0).setCellValue("ApplicationId");;
				header.createCell(1).setCellValue("BatchAckId");
				header.createCell(2).setCellValue("ProcessedDate");
				header.createCell(3).setCellValue("Status");
				header.createCell(4).setCellValue("uniqueId");
				header.createCell(5).setCellValue("LoanAppplicationNumber");
				header.createCell(6).setCellValue("farmerId");


				System.out.println("query===="+process_query);

				try {
					Statement stmt = c.createStatement();
					ResultSet rs = stmt.executeQuery( process_query );


					int count=1;
					while(rs.next())
					{
						XSSFRow valueRow = sheet.createRow(count);


						valueRow.createCell(0).setCellValue(rs.getString("ApplicationId"));
						valueRow.createCell(1).setCellValue(rs.getString("BatchAckId"));
						valueRow.createCell(2).setCellValue(rs.getDate("ProcessedDate"));
						valueRow.createCell(3).setCellValue(rs.getString("Status"));
						valueRow.createCell(4).setCellValue(rs.getString("uniqueId"));
						valueRow.createCell(5).setCellValue(rs.getString("LoanAppplicationNumber"));
						valueRow.createCell(6).setCellValue(rs.getString("farmerId"));
						count++;


					}



					FileOutputStream outputStream = new FileOutputStream(filePath+"\\local\\processedFile_"+fy+"_"+date_to_string+".xlsx");
					workbook.write(outputStream);
					workbook.close();
					textArea.append("\nFile Downloaded Successfully!!!");
					String[] options = {"Close", "Proceed"};
					int x = JOptionPane.showOptionDialog(null, "File Downloaded Successfully. Do you want to open the Folder?",
							"Choose an option",
							JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
					//System.out.println(x);
					if(x==1)
					{
						String FolderName=filePath+"\\local\\";//Write your complete path here
						try {
							Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + FolderName);
						} catch (IOException ex) {
							ex.printStackTrace();
							JOptionPane.showMessageDialog(null,"Something Went Wrong");
						}
					}

					c.close();
					stmt.close();


				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null,"Something Went Wrong");
				}




			}
		});
		btnNewButton_2.setBounds(675, 85, 179, 37);
		panel.add(btnNewButton_2);

		
		//Download Basic details batches error list
		JButton btnNewButton_3 = new JButton("Download Error List");
		btnNewButton_3.setBackground(Color.CYAN);
		btnNewButton_3.setForeground(Color.BLACK);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {


				String fy=comboBox.getSelectedItem().toString();
				Date dateNow = new Date();

				//change date into string yyyyMMdd format example "20110914"
				SimpleDateFormat dateformatyyyyMMdd = new SimpleDateFormat("ddMMyy");
				String date_to_string = dateformatyyyyMMdd.format(dateNow);

				DBConnection db=new DBConnection();
				Connection c =db.ConnectionString(prop);

				String process_query = "select * from kcc_iss.\"Batch_Processed_"+fy+"\" where \"isDeleted\" isnull and \"Status\"='0' ";

				textArea.append(process_query);

				textArea.append("\nFile Download is in process...");
				Workbook workbook = new XSSFWorkbook();

				XSSFCellStyle style1 = (XSSFCellStyle) workbook.createCellStyle();
				XSSFFont my_font=(XSSFFont) workbook.createFont();
				my_font.setBold(true);
				style1.setFont(my_font);


				XSSFSheet sheet = (XSSFSheet) workbook.createSheet("Rejected List");
				XSSFFont font = (XSSFFont) workbook.createFont();
				XSSFRow header = sheet.createRow(0);

				header.createCell(0).setCellValue("ApplicationId");;
				header.createCell(1).setCellValue("BatchAckId");
				header.createCell(2).setCellValue("ProcessedDate");
				header.createCell(3).setCellValue("Status");
				header.createCell(4).setCellValue("uniqueId");
				header.createCell(5).setCellValue("error");


				System.out.println("query===="+process_query);

				try {
					Statement stmt = c.createStatement();
					ResultSet rs = stmt.executeQuery( process_query );


					int count=1;
					while(rs.next())
					{
						XSSFRow valueRow = sheet.createRow(count);


						valueRow.createCell(0).setCellValue(rs.getString("ApplicationId"));
						valueRow.createCell(1).setCellValue(rs.getString("BatchAckId"));
						valueRow.createCell(2).setCellValue(rs.getDate("ProcessedDate"));
						valueRow.createCell(3).setCellValue(rs.getString("Status"));
						valueRow.createCell(4).setCellValue(rs.getString("uniqueId"));
						valueRow.createCell(5).setCellValue(rs.getString("error"));
						count++;


					}



					FileOutputStream outputStream = new FileOutputStream(filePath+"\\local\\rejectedList_"+fy+"_"+date_to_string+".xlsx");
					workbook.write(outputStream);
					workbook.close();
					textArea.append("\nFile Downloaded Successfully!!!");
					String[] options = {"Close", "Proceed"};
					int x = JOptionPane.showOptionDialog(null, "File Downloaded Successfully. Do you want to open the Folder?",
							"Choose an option",
							JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
					//System.out.println(x);
					if(x==1)
					{
						String FolderName=filePath+"\\local\\";//Write your complete path here
						try {
							Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + FolderName);
						} catch (IOException ex) {
							ex.printStackTrace();
							JOptionPane.showMessageDialog(null,"Something Went Wrong");
						}
					}

					c.close();
					stmt.close();


				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null,"Something Went Wrong");
				}





			}
		});
		btnNewButton_3.setBounds(388, 159, 179, 37);
		panel.add(btnNewButton_3);




		panel2.setLayout(null);

		JButton btnNewButton_4 = new JButton("Claim");
		btnNewButton_4.setBackground(Color.CYAN);
		btnNewButton_4.setForeground(Color.BLACK);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//textArea.append(fy);
				String fy= comboBox_3.getSelectedItem().toString();
				int batchCount= Integer.parseInt( textField_1.getText());
				String claimType=comboBox_2.getSelectedItem().toString();
				String statusJson="";
				try
				{
					if(claimType.equals("IS"))
					{
						ISClaim bs=new ISClaim();
						statusJson=bs.BatchProcessing(prop, fy,batchCount, textArea_1);
					}
					else
					{
						ISnPRIClaim bs=new ISnPRIClaim();
						statusJson=bs.BatchProcessing(prop, fy,batchCount,textArea_1);
					}


					JSONParser parser = new JSONParser();  
					System.out.println("==="+statusJson);



					JSONObject json = (JSONObject) parser.parse(statusJson);
					if(json.get("responseCode").equals("200"))
					{
						JOptionPane.showMessageDialog(null,"Batch Status updated successfully!!");
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Something Went Wrong");
					}
				}
				catch(Exception e1)
				{
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null,"Something Went Wrong");
				}
			}
		});
		btnNewButton_4.setBounds(77, 105, 180, 36);
		panel2.add(btnNewButton_4);
		
		JButton btnNewButton_4_1 = new JButton("Get Status");
		btnNewButton_4_1.setBackground(Color.CYAN);
		btnNewButton_4_1.setForeground(Color.BLACK);
		btnNewButton_4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String fy=comboBox_3.getSelectedItem().toString();
				GetClaimBatchStatus bs=new GetClaimBatchStatus();
				try {

					//textArea.append(fy);
					String statusJson=bs.BatchStatus(prop, fy,textArea_1);

					JSONParser parser = new JSONParser();  
					System.out.println("==="+statusJson);



					JSONObject json = (JSONObject) parser.parse(statusJson);
					if(json.get("responseCode").equals("200"))
					{
						JOptionPane.showMessageDialog(null,"Batch Status updated successfully!!");
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Something Went Wrong");
					}

				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 


			}
		});
		btnNewButton_4_1.setBounds(360, 105, 180, 36);
		panel2.add(btnNewButton_4_1);
		
		

		JButton btnNewButton_5 = new JButton("Download Processed");
		btnNewButton_5.setBackground(Color.CYAN);
		btnNewButton_5.setForeground(Color.BLACK);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {


				String fy=comboBox_3.getSelectedItem().toString();
				Date dateNow = new Date();

				//change date into string yyyyMMdd format example "20110914"
				SimpleDateFormat dateformatyyyyMMdd = new SimpleDateFormat("ddMMyy");
				String date_to_string = dateformatyyyyMMdd.format(dateNow);

				DBConnection db=new DBConnection();
				Connection c =db.ConnectionString(prop);

				String process_query = "select * from kcc_iss.\"KCC_ISS_CLAIM_BATCH_PROCESSED_"+fy+"\" where \"isDeleted\" isnull and \"Status\"='1' ";

				textArea_1.append("\n"+process_query);

				textArea_1.append("\nFile Download is in process...");
				Workbook workbook = new XSSFWorkbook();

				XSSFCellStyle style1 = (XSSFCellStyle) workbook.createCellStyle();
				XSSFFont my_font=(XSSFFont) workbook.createFont();
				my_font.setBold(true);
				style1.setFont(my_font);


				XSSFSheet sheet = (XSSFSheet) workbook.createSheet("processed_batch");
				XSSFFont font = (XSSFFont) workbook.createFont();
				XSSFRow header = sheet.createRow(0);

				header.createCell(0).setCellValue("LoanAppplicationNumber");;
				header.createCell(1).setCellValue("BatchAckId");
				header.createCell(2).setCellValue("uniqueId");
				header.createCell(3).setCellValue("ClaimDate");
				header.createCell(4).setCellValue("Status");
				header.createCell(5).setCellValue("ClaimAmount");
				header.createCell(6).setCellValue("claim_type");
				header.createCell(7).setCellValue("claimNumber");


				System.out.println("query===="+process_query);

				try {
					Statement stmt = c.createStatement();
					ResultSet rs = stmt.executeQuery( process_query );


					int count=1;
					while(rs.next())
					{
						XSSFRow valueRow = sheet.createRow(count);


						valueRow.createCell(0).setCellValue(rs.getString("LoanAppplicationNumber"));
						valueRow.createCell(1).setCellValue(rs.getString("BatchAckId"));
						valueRow.createCell(2).setCellValue(rs.getString("uniqueId"));
						valueRow.createCell(3).setCellValue(rs.getDate("ClaimDate"));
						valueRow.createCell(4).setCellValue(rs.getString("Status"));
						valueRow.createCell(5).setCellValue(rs.getFloat("ClaimAmount"));
						valueRow.createCell(6).setCellValue(rs.getString("claim_type"));
						valueRow.createCell(7).setCellValue(rs.getString("claimNumber"));
						count++;


					}



					FileOutputStream outputStream = new FileOutputStream(filePath+"\\local\\ClaimProcessedFile_"+fy+"_"+date_to_string+".xlsx");
					workbook.write(outputStream);
					workbook.close();
					textArea_1.append("\nFile Downloaded Successfully!!");
					String[] options = {"Close", "Proceed"};
					int x = JOptionPane.showOptionDialog(null, "File Downloaded Successfully. Do you want to open the Folder?",
							"Choose an option",
							JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
					//System.out.println(x);
					if(x==1)
					{
						String FolderName=filePath+"\\local\\";//Write your complete path here
						try {
							Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + FolderName);
						} catch (IOException ex) {
							ex.printStackTrace();
							JOptionPane.showMessageDialog(null,"Something Went Wrong");
						}
					}

					c.close();
					stmt.close();


				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null,"Something Went Wrong");
				}





			}
		});
		btnNewButton_5.setBounds(638, 105, 180, 36);
		panel2.add(btnNewButton_5);

		JButton btnNewButton_6 = new JButton("Download Failed");
		btnNewButton_6.setBackground(Color.CYAN);
		btnNewButton_6.setForeground(Color.BLACK);
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {



				String fy=comboBox_3.getSelectedItem().toString();
				Date dateNow = new Date();

				//change date into string yyyyMMdd format example "20110914"
				SimpleDateFormat dateformatyyyyMMdd = new SimpleDateFormat("ddMMyy");
				String date_to_string = dateformatyyyyMMdd.format(dateNow);

				DBConnection db=new DBConnection();
				Connection c =db.ConnectionString(prop);

				String process_query = "select * from kcc_iss.\"KCC_ISS_CLAIM_BATCH_PROCESSED_"+fy+"\" where \"isDeleted\" isnull and \"Status\"='0' ";

				textArea_1.append("\n"+process_query);

				textArea_1.append("\nFile Download is in process...");
				Workbook workbook = new XSSFWorkbook();

				XSSFCellStyle style1 = (XSSFCellStyle) workbook.createCellStyle();
				XSSFFont my_font=(XSSFFont) workbook.createFont();
				my_font.setBold(true);
				style1.setFont(my_font);


				XSSFSheet sheet = (XSSFSheet) workbook.createSheet("processed_batch");
				XSSFFont font = (XSSFFont) workbook.createFont();
				XSSFRow header = sheet.createRow(0);

				header.createCell(0).setCellValue("LoanAppplicationNumber");;
				header.createCell(1).setCellValue("BatchAckId");
				header.createCell(2).setCellValue("uniqueId");
				header.createCell(3).setCellValue("ClaimDate");
				header.createCell(4).setCellValue("Status");
				header.createCell(5).setCellValue("error");


				System.out.println("query===="+process_query);

				try {
					Statement stmt = c.createStatement();
					ResultSet rs = stmt.executeQuery( process_query );


					int count=1;
					while(rs.next())
					{
						XSSFRow valueRow = sheet.createRow(count);


						valueRow.createCell(0).setCellValue(rs.getString("LoanAppplicationNumber"));
						valueRow.createCell(1).setCellValue(rs.getString("BatchAckId"));
						valueRow.createCell(2).setCellValue(rs.getString("uniqueId"));
						valueRow.createCell(3).setCellValue(rs.getDate("ClaimDate"));
						valueRow.createCell(4).setCellValue(rs.getString("Status"));
						valueRow.createCell(5).setCellValue(rs.getString("error"));
						count++;


					}



					FileOutputStream outputStream = new FileOutputStream(filePath+"\\local\\Claim_Rejected_File_"+fy+"_"+date_to_string+".xlsx");
					workbook.write(outputStream);
					workbook.close();
					textArea_1.append("\nFile Downloaded Successfully!!");
					String[] options = {"Close", "Proceed"};
					int x = JOptionPane.showOptionDialog(null, "File Downloaded Successfully. Do you want to open the Folder?",
							"Choose an option",
							JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
					//System.out.println(x);
					if(x==1)
					{
						String FolderName=filePath+"\\local\\";//Write your complete path here
						try {
							Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler " + FolderName);
						} catch (IOException ex) {
							ex.printStackTrace();
							JOptionPane.showMessageDialog(null,"Something Went Wrong");
						}
					}

					c.close();
					stmt.close();


				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null,"Something Went Wrong");
				}






			}
		});
		btnNewButton_6.setBounds(360, 173, 180, 36);
		panel2.add(btnNewButton_6);



		

		window.getContentPane().add(tp,BorderLayout.CENTER);


		// TODO Auto-generated method stub

	}

	public void show() {
		window.setVisible(true);

	}
	public static Properties readPropertiesFile(String fileName) throws IOException {
		FileInputStream propFile = null;
		Properties prop = null;
		try {
			propFile = new FileInputStream(fileName);
			prop = new Properties();
			prop.load(propFile);
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException ex) {
			ex.printStackTrace();
		} finally {
			propFile.close();
		}
		return prop;
	}
}
