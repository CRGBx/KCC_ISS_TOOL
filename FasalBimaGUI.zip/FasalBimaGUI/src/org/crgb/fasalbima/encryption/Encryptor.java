package org.crgb.fasalbima.encryption;
import java.util.Properties;

import javax.crypto.Cipher;  
import javax.crypto.spec.IvParameterSpec;  

import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.crgb.fasalbima.common.ReadPropFile;


public class Encryptor   
{  
    /* Private variable declaration */  
	
	//Use Banks Secret Key and IV 
    
	static String filePath = System.getProperty("user.dir");
   
    /* Encryption Method */  
    public static String encrypt(String value) {
    	try {
    		

    		System.out.println("====dir======"+filePath);
    		Properties prop = ReadPropFile.readPropertiesFile(filePath+"\\resources\\config.properties");
 
    	      
    		IvParameterSpec iv = new IvParameterSpec(((String) prop.get("SALTVALUE")).getBytes("UTF-8"));
    		SecretKeySpec skeySpec = new SecretKeySpec(((String) prop.get("SECRET_KEY")).getBytes("UTF-8"), "AES");
    		
    	

    		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
    		//cipher.getBlockSize();
    		
    		System.out.println(cipher.getBlockSize());
    		cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);

    		
    		byte[] encrypted = cipher.doFinal(value.getBytes());
    		return parseByte2HexStr(encrypted);
    	} catch (Exception ex) {
    		ex.printStackTrace();
    	}
    	return null;
    }
    
    public static String parseByte2HexStr(byte buf[]) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < buf.length; i++) {
            String hex = Integer.toHexString(buf[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            sb.append(hex.toUpperCase());
        }
        return sb.toString();
    }
    
    public static String decrypt(String encrypted) {
    	try {
    		Properties prop = ReadPropFile.readPropertiesFile(filePath+"\\resources\\config.properties");
    		IvParameterSpec iv = new IvParameterSpec(((String) prop.get("SALTVALUE")).getBytes("UTF-8"));
    		SecretKeySpec skeySpec = new SecretKeySpec(((String) prop.get("SECRET_KEY")).getBytes("UTF-8"), "AES");

    		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
    		cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
    		byte[] original = cipher.doFinal(Hex.decodeHex(encrypted.toCharArray()));

    		return new String(original);
    	} catch (Exception ex) {
    		ex.printStackTrace();
    	}

    	return null;
    } 
    /* Driver Code */  
    
}  