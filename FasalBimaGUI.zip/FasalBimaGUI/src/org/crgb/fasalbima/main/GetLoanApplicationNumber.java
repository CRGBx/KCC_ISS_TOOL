package org.crgb.fasalbima.main;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.crgb.fasalbima.common.*;
import org.crgb.fasalbima.dbcom.*;
import org.crgb.fasalbima.obj.*;
import org.crgb.fasalbima.encryption.*;
public class GetLoanApplicationNumber {
	CloseableHttpClient httpClient = HttpClients.createDefault();
	public void GetComplete(Properties prop) throws IOException, ParseException, SQLException {

		String abc = "";
		String def = "";
		

		UniqueIdObj dob = new UniqueIdObj();
		RequestDto dobj = new RequestDto();
		HttpPost postreq = new
				HttpPost("https://fasalrin.gov.in/v1/issintegration/databyapplicationnumbers");


		//dob.setRegnNo("HR03P8989");




		DBConnection db=new DBConnection();
		Connection c =db.ConnectionString(prop);
		Statement stmt = c.createStatement();


		String sql = "select distinct \"BatchAckId\" from loanflow.\"Batch_Processed_2022_23\" a where \"Status\"='1' and \"isDeleted\" isnull and not exists (select * from loanflow.\"Basic_Details_2022_23\" b where a.\"ApplicationId\"=b.\"ApplicationId\");";
		//String sql="select * from loanflow.\"Basic_Details\" where \"ApplicationId\"='00000077084728521'";

		System.out.println("Basic Details==="+sql);

		ResultSet rs = stmt.executeQuery( sql );


		//dob.setRegnNo("HR03P8989");


		while(rs.next())
		{
			//				String basicId="281123063";
			//				String batchId=basicId+"0000"+batchCount;
			//				if(batchCount>9&&batchCount<100)
			//					batchId=basicId+"000"+batchCount;
			//				else if(batchCount>99&&batchCount<1000)
			//					batchId=basicId+"00"+batchCount;
			//				else if(batchCount>999)
			//					batchId=basicId+"0"+batchCount;
			//
			//				batchCount++;
			dob.setBatchAckId(rs.getString("BatchAckId"));

			Statement stmtApp = c.createStatement();

			String sqlApp = "select \"LoanAppplicationNumber\" from loanflow.\"Batch_Processed_2022_23\" a where \"BatchAckId\"='"+rs.getString("BatchAckId")+"' and \"Status\"='1' and not exists (select 1 from loanflow.\"Basic_Details_2022_23\" b where a.\"ApplicationId\"=b.\"ApplicationId\") and \"isDeleted\" isnull limit 30 ";
			//String sql="select * from loanflow.\"Basic_Details\" where \"ApplicationId\"='00000077084728521'";

			System.out.println("Basic Details==="+sqlApp);

			ResultSet rsApp = stmtApp.executeQuery( sqlApp );
			ArrayList<String> loanAppArr=new ArrayList<>(); 
			while(rsApp.next())
			{
				loanAppArr.add(rsApp.getString("LoanAppplicationNumber"));
			}
			stmtApp.close();
			rsApp.close();

			for(int k=0;k<loanAppArr.size();k=k+1)
			{


				JSONArray uniqueIdArrObj=new JSONArray();


				//dob.setRegnNo("HR03P8989");
				for(int j=k;j<k+1&&j<loanAppArr.size();j++)
				{
					uniqueIdArrObj.add(loanAppArr.get(j));
				}

				//				for(rsApp.next())
				//				{
				//					uniqueIdArrObj.add(rsApp.getString("LoanAppplicationNumber"));
				//				}

				dob.setApplicationNumbers(uniqueIdArrObj);
				//AppObj.put("applicationNumbers", uniqueIdArrObj);

				abc = convertToJson(dob);
				String reqEncrypt = "";
				try {
					//					String key = prop.getProperty("key");
					//					System.out.println("ddv " + key);
					reqEncrypt = Encryptor.encrypt(abc);
					dobj.setClientId(prop.getProperty("clientId"));
					dobj.setEncData(reqEncrypt);

					def = convertToJson(dobj);

					System.out.println("Req======"+abc);

					System.out.println("Request Encrypted===="+def);
					StringEntity input = new StringEntity(def);
					input.setContentType("application/json");
					postreq.setEntity(input);
					//postreq.addHeader("AccessToken", key);
					CloseableHttpResponse res = httpClient.execute(postreq);
					HttpEntity entity = res.getEntity();
					String content = EntityUtils.toString(entity);
					System.out.println("Encrypted Response====="+content);
					JSONParser enparser = new JSONParser();  
					JSONObject enjson = (JSONObject) enparser.parse(content);  



					ObjectMapper mapper = new ObjectMapper();
					dobj = mapper.readValue(content, RequestDto.class);
					String decrypt = Encryptor.decrypt(dobj.getEncData());
					System.out.println("Decrypted Response====="+decrypt);

					JSONParser parser = new JSONParser();  
					JSONArray json = (JSONArray) parser.parse(decrypt);  

					//System.out.println("Inside if statement");
					String INSERT_USERS_SQL = "insert into loanflow.\"Basic_Details_2022_23\"" + "  "
							+ "(\"ApplicationId\",\"beneficiaryName\", \"beneficiaryPassbookName\", \"aadhaarNumber\","
							+ "mobile,dob,gender, \"socialCategory\", \"farmerCategory\", \"farmerType\",\"relativeType\",\"kccLimitSanctionedAmount\",\"kccDrawingLimitForFY\",\"kccLoanSanctionedDate\")"
							+ " VALUES " +
							" (?, ?, ?,?, ?, ?,?, ?, ?,?,?,?,?,?);";
					PreparedStatement preparedStatement = c.prepareStatement(INSERT_USERS_SQL);
					for ( int i=0;i<json.size();i++) {
						JSONObject appObj=(JSONObject) json.get(i);
						JSONObject basicObj=(JSONObject) appObj.get("basicDetails");
						JSONObject ActObj=(JSONObject) appObj.get("accountDetails");
						JSONObject loanObj=(JSONObject) appObj.get("loanDetails");
						preparedStatement.setString(1, (String) ActObj.get("accountNumber"));
						preparedStatement.setString(2, (String) basicObj.get("beneficiaryName"));
						preparedStatement.setString(3, (String) basicObj.get("beneficiaryPassbookName"));
						preparedStatement.setString(4, (String) basicObj.get("aadhaarNumber"));
						preparedStatement.setString(5, (String) basicObj.get("mobile"));
						preparedStatement.setString(6, (String) basicObj.get("dob"));
						preparedStatement.setFloat(7,  (Long) basicObj.get("gender"));
						preparedStatement.setFloat(8, (Long) basicObj.get("socialCategory"));
						preparedStatement.setFloat(9, (Long) basicObj.get("farmerCategory"));
						preparedStatement.setFloat(10, (Long) basicObj.get("farmerType"));
						preparedStatement.setFloat(11, (Long) basicObj.get("relativeType"));

						//System.out.println("=test data kcc Limit===="+loanObj.get("kccLimitSanctionedAmount"));
						preparedStatement.setDouble(12, (double) Double.parseDouble((String) loanObj.get("kccLimitSanctionedAmount")));
						preparedStatement.setDouble(13, (double) Double.parseDouble((String)loanObj.get("kccDrawingLimitForFY")));



						Date date1=(Date) new SimpleDateFormat("yyyy-MM-dd").parse((String) loanObj.get("kccLoanSanctionedDate"));
						java.sql.Date TRAN_DATE = new java.sql.Date(date1.getTime());

						preparedStatement.setDate(14, TRAN_DATE);

						//preparedStatement.setDouble(15, (double) basicObj.get("kccDrawingLimitForFY"));


						preparedStatement.addBatch();
					}

					//long start = System.currentTimeMillis();
					int[] inserted = preparedStatement.executeBatch();
					preparedStatement.close();
					//long end = System.currentTimeMillis();



				} catch (Exception e) {

					e.printStackTrace();
					//return "{\"responseCode\":\"201\"}";
				}
			}
		}
		rs.close();

		stmt.close();

		c.close();

	}

	public static String convertToJson(UniqueIdObj dob) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(dob);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	public static String convertToJson(RequestDto vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	

}
