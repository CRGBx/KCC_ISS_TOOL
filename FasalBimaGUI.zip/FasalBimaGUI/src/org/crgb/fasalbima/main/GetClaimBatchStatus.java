package org.crgb.fasalbima.main;


import com.fasterxml.jackson.databind.ObjectMapper;

import java.awt.TextArea;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.Properties;

import javax.swing.JTextArea;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.crgb.fasalbima.common.*;
import org.crgb.fasalbima.dbcom.*;
import org.crgb.fasalbima.obj.*;
import org.crgb.fasalbima.encryption.*;
public class GetClaimBatchStatus {
	CloseableHttpClient httpClient = HttpClients.createDefault();
	public  String  BatchStatus(Properties prop, String fy, TextArea textArea_1) throws IOException, SQLException {

		String abc = "";
		String def = "";
		BatchStatus dob = new BatchStatus();
		RequestDto dobj = new RequestDto();
		HttpPost postreq = new
				HttpPost(prop.getProperty("claim_data_ack_id_url"));

		//https://fasalrin.gov.in/v1/issintegration/databybatchackid

		DBConnection db=new DBConnection();
		Connection c =db.ConnectionString(prop);
		Statement stmt = c.createStatement();

		String sql = "select distinct \"BatchAckId\" from kcc_iss.\"KCC_ISS_CLAIM_BATCH_PROCESSED_"+fy+"\" where \"Status\" isnull and \"BatchAckId\" notnull";
		textArea_1.append(sql);
		ResultSet rs = stmt.executeQuery( sql );
		
		while(rs.next())
		{
			dob.setBatchAckId(rs.getString("BatchAckId"));

			abc = convertToJson(dob);
			String reqEncrypt = "";
			try {
//				String key = prop.getProperty("key");
//				System.out.println("ddv " + key);
				reqEncrypt = Encryptor.encrypt(abc);
				dobj.setClientId(prop.getProperty("clientId"));
				dobj.setEncData(reqEncrypt);

				def = convertToJson(dobj);

				System.out.println("Req======"+abc);
				textArea_1.append("\nReq======"+abc);

				System.out.println("Request Encrypted===="+def);
				textArea_1.append("\nRequest Encrypted===="+def);
				StringEntity input = new StringEntity(def);
				input.setContentType("application/json");
				postreq.setEntity(input);
				//postreq.addHeader("AccessToken", key);
				CloseableHttpResponse res = httpClient.execute(postreq);
				HttpEntity entity = res.getEntity();
				String content = EntityUtils.toString(entity);
				System.out.println("Encrypted Response====="+content);
				textArea_1.append("\nEncrypted Response====="+content);
				JSONParser enparser = new JSONParser();  
				JSONObject enjson = (JSONObject) enparser.parse(content);  
				
				boolean enstatus=(boolean) enjson.get("status");
				if(enstatus)
				{
					ObjectMapper mapper = new ObjectMapper();
					dobj = mapper.readValue(content, RequestDto.class);
					String decrypt = Encryptor.decrypt(dobj.getEncData());
					System.out.println("Decrypted Response====="+decrypt);
					textArea_1.append("\nDecrypted Response====="+decrypt);
	
					JSONParser parser = new JSONParser();  
					JSONObject json = (JSONObject) parser.parse(decrypt); 
	
					JSONArray jsonArray =  (JSONArray) json.get("applications") ;
					
					
					//System.out.println(al.size());
					//Long status=(Long) json.get("status");
					System.out.println("Inside if statement");
					String INSERT_USERS_SQL = "update kcc_iss.\"KCC_ISS_CLAIM_BATCH_PROCESSED_"+fy+"\"" + " set \"Status\"=?, error=?,\"claimNumber\"=? where \"uniqueId\"=?";
					PreparedStatement preparedStatement = c.prepareStatement(INSERT_USERS_SQL);
					for(int i=0;i<jsonArray.size();i++)
					{
						JSONObject appJson = (JSONObject) jsonArray.get(i); 
						Long status=(Long) appJson.get("applicationStatus");
						preparedStatement.setString(1,status.toString());
						//Long status=(Long) appJson.get("applicationStatus");
						if(status==1)
						{
							preparedStatement.setString(2, "");
							preparedStatement.setString(3,(String) appJson.get("claimNumber"));
							
						}
						else
						{
							preparedStatement.setString(2, (String) appJson.get("errors"));
							preparedStatement.setString(3, "");
							
						}
						preparedStatement.setString(4, (String) appJson.get("uniqueId"));
						preparedStatement.addBatch();
	
						//long start = System.currentTimeMillis();
	
						//long end = System.currentTimeMillis();
					}
					int[] inserted = preparedStatement.executeBatch();
				}
				return "{\"responseCode\":\"200\"}";

				//return decrypt;
			} catch (Exception e) {

				e.printStackTrace();
				return "{\"responseCode\":\"201\"}";
			}
		}
		rs.close();

		stmt.close();

		c.close();
		return "{\"responseCode\":\"200\"}";

	}

	public static String convertToJson(RequestDto vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	public static String convertToJson(BatchStatus vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	
}


