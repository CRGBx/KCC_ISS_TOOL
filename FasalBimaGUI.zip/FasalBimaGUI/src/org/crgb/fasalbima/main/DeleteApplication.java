package org.crgb.fasalbima.main;


import com.fasterxml.jackson.databind.ObjectMapper;
import org.crgb.fasalbima.common.*;
import org.crgb.fasalbima.dbcom.*;
import org.crgb.fasalbima.obj.*;
import org.crgb.fasalbima.encryption.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class DeleteApplication {
	CloseableHttpClient httpClient = HttpClients.createDefault();
	public  String  AppDeletion(Properties prop) throws IOException, SQLException {

		String abc = "";
		String def = "";
		
		BatchStatus dob = new BatchStatus();
		RequestDto dobj = new RequestDto();
		HttpPost postreq = new
				HttpPost(prop.getProperty("delete_batch_url"));

		//https://fasalrin.gov.in/v1/issintegration/databybatchackid

		DBConnection db=new DBConnection();
		Connection c =db.ConnectionString(prop);
		Statement stmt = c.createStatement();

		//String sql = "select \"applicationNumbers\" from loanflow.\"Batch_Processed_2022_23\"  where \"isDeleted\" isnull and \"Status\"='1' ";
		
		String sql = "select distinct \"BatchAckId\" from loanflow.\"Batch_Processed_2022_23\"  where \"isDeleted\" isnull and \"Status\"='1' and to_be_deleted='1' ";

		ResultSet rs = stmt.executeQuery( sql );

		
		//dob.setRegnNo("HR03P8989");

		
		while(rs.next())
		{
			JSONObject AppObj=new JSONObject();
			

			AppObj.put("batchId", rs.getString("BatchAckId"));
			AppObj.put("financialYear", "2022-2023");
			
			ArrayList<String> uniId=new ArrayList<String>();
			
			Statement stmtApp = c.createStatement();

			String sqlApp = "select * from loanflow.\"Batch_Processed_2022_23\" a where \"BatchAckId\"='"+rs.getString("BatchAckId")+"' and \"Status\"='1' and \"isDeleted\" isnull and to_be_deleted='1' ";
			//String sql="select * from loanflow.\"Basic_Details\" where \"ApplicationId\"='00000077084728521'";

			System.out.println("Basic Details==="+sqlApp);

			ResultSet rsApp = stmtApp.executeQuery( sqlApp );
			
			
			JSONArray uniqueIdArrObj=new JSONArray();
			
			while(rsApp.next())
			{
				uniqueIdArrObj.add(rsApp.getString("LoanAppplicationNumber"));
				uniId.add(rsApp.getString("uniqueId"));
			}
			AppObj.put("applicationNumbers", uniqueIdArrObj);
			
			rsApp.close();

			stmtApp.close();
			
			abc = convertToJson(AppObj);
			String reqEncrypt = "";
			try {
				//			String key = prop.getProperty("key");
				//			System.out.println("ddv " + key);
				reqEncrypt = Encryptor.encrypt(abc);
				dobj.setClientId(prop.getProperty("clientId"));
				dobj.setEncData(reqEncrypt);

				def = convertToJson(dobj);

				System.out.println("Req======"+abc);

				System.out.println("Request Encrypted===="+def);
				StringEntity input = new StringEntity(def);
				input.setContentType("application/json");
				postreq.setEntity(input);
				//postreq.addHeader("AccessToken", key);
				CloseableHttpResponse res = httpClient.execute(postreq);
				HttpEntity entity = res.getEntity();


				String content = EntityUtils.toString(entity);
				System.out.println("Encrypted Response====="+content);
				ObjectMapper mapper = new ObjectMapper();
				dobj = mapper.readValue(content, RequestDto.class);
				String decrypt = Encryptor.decrypt(dobj.getEncData());
				System.out.println("Decrypted Response====="+decrypt);

				JSONParser parser = new JSONParser();  
				JSONObject json = (JSONObject) parser.parse(decrypt);  
				
				Long status=(Long) json.get("status");
				if(status==1)
				{

					String INSERT_USERS_SQL = "update loanflow.\"Batch_Processed_2022_23\"" + " set \"isDeleted\"='Yes',\"deleteBatchAckId\"=? where \"uniqueId\"=?";
					PreparedStatement preparedStatement = c.prepareStatement(INSERT_USERS_SQL);
					
					for(int i=0;i<uniId.size();i++)
					{
						preparedStatement.setString(1,  (String) json.get("batchAckId"));
						preparedStatement.setString(2, (String) uniId.get(i));
						preparedStatement.addBatch();
	
						//long start = System.currentTimeMillis();
	
						//long end = System.currentTimeMillis();
					}
					int[] inserted = preparedStatement.executeBatch();
				}
				else
				{
					String INSERT_USERS_SQL = "update loanflow.\"Batch_Processed_2022_23\"" + " set \"isDeleted\"='Yes',\"deleteBatchAckId\"=?,delete_error=? where \"uniqueId\"=?";
					PreparedStatement preparedStatement = c.prepareStatement(INSERT_USERS_SQL);
					
					for(int i=0;i<uniId.size();i++)
					{
						preparedStatement.setString(1,  (String) json.get("batchAckId"));
						preparedStatement.setString(2, "error");
						preparedStatement.setString(3, (String) uniId.get(i));
						preparedStatement.addBatch();
	
						//long start = System.currentTimeMillis();
	
						//long end = System.currentTimeMillis();
					}
					int[] inserted = preparedStatement.executeBatch();
				}
				//long start = System.currentTimeMillis();
				
				
				//return decrypt;
			} catch (Exception e) {

				e.printStackTrace();
				//return "{\"responseCode\":\"201\"}";
			}
			
		}
		
		rs.close();

		stmt.close();

		c.close();
		return "";


	}

	public static String convertToJson(JSONObject vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	public static String convertToJson(RequestDto vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}
}


