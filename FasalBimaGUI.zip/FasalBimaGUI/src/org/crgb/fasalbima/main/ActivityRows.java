package org.crgb.fasalbima.main;

import org.crgb.fasalbima.*;
public class ActivityRows {
	private String landVillage;
	private String surveyNumber;
	private String khataNumber;
	private int landArea;
	private int landType;
	private String cropCode;
	private int season;
	 
//	private String plantationCode;
//	private String plantationArea;
//	private String liveStockType;
//	private String liveStockCode;
//	private String unitCount;
//	private String inlandType;
//	private String totalUnits;
//	private String totalArea;
//	private String marineType;
	
//	public String getPlantationCode() {
//		return plantationCode;
//	}
//	public void setPlantationCode(String plantationCode) {
//		this.plantationCode = plantationCode;
//	}
//	public String getPlantationArea() {
//		return plantationArea;
//	}
//	public void setPlantationArea(String plantationArea) {
//		this.plantationArea = plantationArea;
//	}
//	public String getLiveStockType() {
//		return liveStockType;
//	}
//	public void setLiveStockType(String liveStockType) {
//		this.liveStockType = liveStockType;
//	}
//	public String getLiveStockCode() {
//		return liveStockCode;
//	}
//	public void setLiveStockCode(String liveStockCode) {
//		this.liveStockCode = liveStockCode;
//	}
//	public String getUnitCount() {
//		return unitCount;
//	}
//	public void setUnitCount(String unitCount) {
//		this.unitCount = unitCount;
//	}
//	public String getInlandType() {
//		return inlandType;
//	}
//	public void setInlandType(String inlandType) {
//		this.inlandType = inlandType;
//	}
//	public String getTotalUnits() {
//		return totalUnits;
//	}
//	public void setTotalUnits(String totalUnits) {
//		this.totalUnits = totalUnits;
//	}
//	public String getTotalArea() {
//		return totalArea;
//	}
//	public void setTotalArea(String totalArea) {
//		this.totalArea = totalArea;
//	}
//	public String getMarineType() {
//		return marineType;
//	}
//	public void setMarineType(String marineType) {
//		this.marineType = marineType;
//	}
	public String getLandVillage() {
		return landVillage;
	}
	public void setLandVillage(String landVillage) {
		this.landVillage = landVillage;
	}
	public String getSurveyNumber() {
		return surveyNumber;
	}
	public void setSurveyNumber(String surveyNumber) {
		this.surveyNumber = surveyNumber;
	}
	
	public String getKhataNumber() {
		return khataNumber;
	}
	public void setKhataNumber(String khataNumber) {
		this.khataNumber = khataNumber;
	}
	public int getLandArea() {
		return landArea;
	}
	public void setLandArea(int landArea) {
		this.landArea = landArea;
	}
	public int getLandType() {
		return landType;
	}
	public void setLandType(int landType) {
		this.landType = landType;
	}
	
	public String getCropCode() {
		return cropCode;
	}
	public void setCropCode(String cropCode) {
		this.cropCode = cropCode;
	}
	public int getSeason() {
		return season;
	}
	public void setSeason(int season) {
		this.season = season;
	}

}
