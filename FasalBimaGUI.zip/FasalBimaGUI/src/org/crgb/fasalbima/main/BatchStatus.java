package org.crgb.fasalbima.main;


public class BatchStatus {
	private String batchAckId;

	public String getBatchAckId() {
		return batchAckId;
	}

	public void setBatchAckId(String batchAckId) {
		this.batchAckId = batchAckId;
	}
}
