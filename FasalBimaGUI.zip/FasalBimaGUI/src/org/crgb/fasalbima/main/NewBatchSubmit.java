package org.crgb.fasalbima.main;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.crgb.fasalbima.common.*;
import org.crgb.fasalbima.dbcom.*;
import org.crgb.fasalbima.obj.*;
import org.crgb.fasalbima.encryption.*;

public class NewBatchSubmit {
	CloseableHttpClient httpClient = HttpClients.createDefault();
	public  String  BatchProcessing(Properties prop) throws IOException, ParseException, SQLException {

		String abc = "";
		String def = "";
		

		RequestDto dobj = new RequestDto();
		HttpPost postreq = new
				HttpPost("https://fasalrin.gov.in/v1/issintegration/submitbatch");


		//dob.setRegnNo("HR03P8989");
		boolean flag=true;
		int batchCount=1;
		
		while(flag)
		{
			flag=false;
			JSONObject Batch=new JSONObject();
			String basicId="061223063";
			String batchId=basicId+"0000"+batchCount;
			if(batchCount>9&&batchCount<100)
				batchId=basicId+"000"+batchCount;
			else if(batchCount>99&&batchCount<1000)
				batchId=basicId+"00"+batchCount;
			else if(batchCount>999)
				batchId=basicId+"0"+batchCount;
			
			batchCount++;
			Batch.put("batchId",batchId);
			Batch.put("financialYear", "2021-2022");
			JSONArray AppArr=new JSONArray();


			DBConnection db=new DBConnection();
			Connection c =db.ConnectionString(prop);
			Statement stmt = c.createStatement();


			String sql = "select i.* from (SELECT a.\"ApplicationId\", \"beneficiaryName\", \"aadhaarNumber\", \"beneficiaryPassbookName\", \r\n"
					+ "a.mobile, dob, gender, \"socialCategory\", \"farmerCategory\", \"farmerType\", \"primaryOccupation\", \"relativeType\", \"relativeName\",pincode,address \r\n"
					+ "FROM loanflow.\"Basic_Details\" a inner join public.\"KCC_ISS_UNIQUE_ACC\" b on acc=\"ApplicationId\"\r\n"
					+ "where \r\n"
					+ "sub='2021-22' and\r\n"
					+ "(a.\"aadhaarNumber\") notnull and \r\n"
					+ "(a.\"mobile\") notnull \r\n"
					+ "and \"socialCategory\" notnull \r\n"
					+ "and \"farmerType\" notnull and  \r\n"
					+ "\"relativeType\" notnull and dob notnull and eligible='1'\r\n"
					+ "and not exists (select 1 from loanflow.\"Batch_Processed\" d where d.\"ApplicationId\"=a.\"ApplicationId\" and \"isDeleted\" isnull) and Exists (select 1  from loanflow.\"KCCExistingLand\" d \r\n"
					+ "inner join loanflow.\"KCCCropDetailExisting\" e on d.\"Id\"=e.\"KCCExistingLandId\" where \r\n"
					+ "LPAD(d.\"AccountNo\",17,'0')=a.\"ApplicationId\" and d.\"fbVillageCode\" notnull and e.\"Crop\"::numeric!=0) and not exists (select 1 from  loanflow.\"KCCCropDetailExisting\" b \r\n"
					+ "inner join loanflow.crop_master d on (b.\"Crop\"::numeric = d.\"cropCode\"::numeric) where a.\"ApplicationId\"=lpad(b.\"AccountNo\",17,'0') \r\n"
					+ "and \"categoryCode\"='2')) i limit 1000";
//					+ "inner join loanflow.\"Account_Details\" j on i.\"ApplicationId\"=j.\"ApplicationId\"\r\n"
//					+ "where \"accountHolder\"=1 limit 1000";
			
			System.out.println("Basic Details==="+sql);

			ResultSet rs = stmt.executeQuery( sql );


			int count=1;
			

			ArrayList<Applicant> al=new ArrayList<Applicant>();
			while ( rs.next() ) {
				flag=true;
				JSONObject AppObj=new JSONObject();

				Statement stmtAc = c.createStatement();
				Statement stmtLoan = c.createStatement();

				Statement stmtAct = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				//System.out.println(count);

				String accDet = "SELECT a.*,b.\"branchCode\" as \"brCode\" FROM loanflow.\"Account_Details\" a inner join loanflow.kcc_master_branch b on a.ifsc=b.\"ifscCode\" where \"ApplicationId\"='"+rs.getString("ApplicationId")+"'";
				String loanDet = "select * from loanflow.\"Loan_Details\" where \"ApplicationId\"='"+rs.getString("ApplicationId")+"'";
				String actDet = "select c.*,\"categoryCode\", CASE WHEN position('RF' in \"cropName\") > 0 THEN \"SOFIrrigatedArea\" ELSE 0 END urr, CASE WHEN position('RF' in \"cropName\") = 0 THEN \"SOFIrrigatedArea\" ELSE 0 END irr from (select *  from loanflow.\"KCCExistingLand\" a inner join loanflow.\"KCCCropDetailExisting\" b on a.\"Id\"=b.\"KCCExistingLandId\"where  lpad(a.\"AccountNo\",17,'0')='"+rs.getString("ApplicationId")+"' ) c inner join loanflow.crop_master d on (c.\"Crop\"::numeric = d.\"cropCode\"::numeric) order by \"TotalArea\" desc\r\n";


				System.out.println("\n\nAcc Details==="+accDet);
				System.out.println("Loan Details==="+loanDet);
				System.out.println("Act Details==="+actDet);

				ResultSet rsAcc = stmtAc.executeQuery( accDet );
				rsAcc.next();

				ResultSet rsLoan = stmtLoan.executeQuery( loanDet );
				rsLoan.next();

				ResultSet rsAct = stmtAct.executeQuery( actDet );
				rsAct.next();





				String uniqueId=batchId+"0000"+count;
				if(count>9&&count<100)
					uniqueId=batchId+"000"+count;
				else if(count>99&&count<1000)
					uniqueId=batchId+"00"+count;
				else if(count>999)
					uniqueId=batchId+"0"+count;
				AppObj.put("uniqueId", uniqueId);
				count++;
				Applicant app=new Applicant();
				app.setApplicationId(rs.getString("ApplicationId"));
				app.setUniqueId(uniqueId);
				al.add(app);
				AppObj.put("recordStatus", 1);

				JSONObject BasicObj=new JSONObject();
				BasicObj.put("beneficiaryName", rs.getString("beneficiaryName"));
				BasicObj.put("aadhaarNumber", rs.getString("aadhaarNumber"));
				BasicObj.put("beneficiaryPassbookName", rs.getString("beneficiaryName"));
				BasicObj.put("mobile",rs.getString("mobile"));
				BasicObj.put("dob", rs.getString("dob"));
				BasicObj.put("gender", rs.getInt("gender"));
				BasicObj.put("farmerCategory", rs.getInt("farmerCategory"));
				BasicObj.put("farmerType", rs.getInt("farmerType"));
				BasicObj.put("primaryOccupation", rs.getInt("primaryOccupation"));
				BasicObj.put("relativeType", rs.getInt("relativeType"));
				BasicObj.put("relativeName", rs.getString("relativeName"));
				BasicObj.put("socialCategory", rs.getInt("socialCategory"));
				AppObj.put("basicDetails", BasicObj);

				JSONObject ResObj=new JSONObject();
				//will be changed
				ResObj.put("residentialVillage", rsAct.getString("fbVillageCode"));
				ResObj.put("residentialAddress", rs.getString("address"));
				ResObj.put("residentialPincode", rs.getString("pincode"));
				AppObj.put("residentialDetails", ResObj);

				JSONObject AccObj=new JSONObject();
				AccObj.put("accountNumber", rsAcc.getString("accountNumber"));
				AccObj.put("branchCode", rsAcc.getString("brCode"));
				int accountHolder=rsAcc.getInt("accountHolder");

				//AccObj.put("accountHolder", rsAcc.getInt("accountHolder"));
				AccObj.put("accountHolder", 1);
				accountHolder=rsAcc.getInt("accountHolder");
				AccObj.put("ifsc", rsAcc.getString("ifsc"));

//				if(accountHolder>1)
//				{
//					JSONArray JointArrObj=new JSONArray();
//					for(int i=0;i<accountHolder;i++)
//					{
//						JSONObject JointObj=new JSONObject();
//						JointObj.put("name", rs.getString("beneficiaryName"));
//						JointObj.put("aadhaarNumber", rs.getString("aadhaarNumber"));
//
//
//						if(i>0)
//						{
//							JointObj.put("isPrimary", 0);
//						}
//						else
//						{
//							JointObj.put("isPrimary", 1);
//						}
//
//						JointArrObj.add(JointObj);
//					}
//
//
//
//
//					AccObj.put("jointAccountHolders", JointArrObj);
//				}
				AppObj.put("accountDetails", AccObj);

				JSONObject LoanObj=new JSONObject();
				LoanObj.put("kccLoanSanctionedDate", rsLoan.getString("kccLoanSanctionedDate"));
				
//				if( Float.valueOf(rsLoan.getString("kccDrawingLimitforFY"))<Float.valueOf(rsLoan.getString("kccLoanSanctionedAmount")))
//					LoanObj.put("kccLimitSanctionedAmount", rsLoan.getString("kccDrawingLimitforFY"));
//				else
					LoanObj.put("kccLimitSanctionedAmount", rsLoan.getString("kccLoanSanctionedAmount"));

				LoanObj.put("kccDrawingLimitForFY", rsLoan.getString("kccLoanSanctionedAmount"));
				AppObj.put("loanDetails", LoanObj);

				JSONArray ActObjArrObj=new JSONArray();

				JSONObject ActObj=new JSONObject();
				JSONObject ActObj2=new JSONObject();
				ActObj.put("activityType", 1);
				ActObj2.put("activityType", 2);
				ActObj.put("loanSanctionedDate", rsLoan.getString("kccLoanSanctionedDate"));
				ActObj2.put("loanSanctionedDate", rsLoan.getString("kccLoanSanctionedDate"));
//				if( Float.valueOf(rsLoan.getString("kccDrawingLimitforFY"))<Float.valueOf(rsLoan.getString("kccLoanSanctionedAmount")))
//				{
//					ActObj.put("loanSanctionedAmount", rsLoan.getString("kccDrawingLimitforFY"));
//					ActObj2.put("loanSanctionedAmount", rsLoan.getString("kccDrawingLimitforFY"));
//				}
//				else
//				{
					ActObj.put("loanSanctionedAmount", rsLoan.getString("kccDrawingLimitforFY"));
					ActObj2.put("loanSanctionedAmount", rsLoan.getString("kccDrawingLimitforFY"));
				//}

				//ActObj.put("loanSanctionedAmount", rsLoan.getString("kccLoanSanctionedAmount"));

				JSONArray ActRowArrObj=new JSONArray();
				JSONArray ActRowArrObj2=new JSONArray();


				int activityType=1;

				int ActCount=0;
				String khataNumber="";
				boolean AccFlag=true;

				rsAct.beforeFirst();
				boolean hort=false;
				boolean cropFlag=false;
				while(rsAct.next())
				{
					
					if(rsAct.getInt("categoryCode")==1)
					{
						cropFlag=true;
						JSONObject ActRowObj=new JSONObject();
						if(ActCount==0)
							khataNumber=rsAct.getString("KhasraNo").replaceAll(" \\(Split\\)", "");
						ActCount++;
						ActRowObj.put("landVillage", rsAct.getString("fbVillageCode"));
						ActRowObj.put("surveyNumber", rsAct.getString("KhasraNo").replaceAll(" \\(Split\\)", ""));
						ActRowObj.put("khataNumber",khataNumber );
						ActRowObj.put("landArea", rsAct.getString("TotalArea"));
						if(rsAct.getFloat("irr")>0)
							ActRowObj.put("landType", 1);
						else
							ActRowObj.put("landType", 2);

						if(rsAct.getString("Season").equals("Kharif"))
							ActRowObj.put("season", 1);
						else if(rsAct.getString("Season").equals("Rabi"))
							ActRowObj.put("season", 2);
						else
							ActRowObj.put("season", 3);


						if(rsAct.getString("Crop").startsWith("0"))
							ActRowObj.put("cropCode",rsAct.getString("Crop"));
						else
							ActRowObj.put("cropCode","0"+rsAct.getString("Crop"));

						ActRowArrObj.add(ActRowObj);
					}
					else
					{
						hort=true;
						JSONObject ActRowObj2=new JSONObject();
						if(ActCount==0)
							khataNumber=rsAct.getString("KhasraNo").replaceAll(" \\(Split\\)", "");
						ActCount++;
						ActRowObj2.put("landVillage", rsAct.getString("fbVillageCode"));
						ActRowObj2.put("surveyNumber", rsAct.getString("KhasraNo").replaceAll(" \\(Split\\)", ""));
						ActRowObj2.put("khataNumber",khataNumber );
						ActRowObj2.put("plantationArea", rsAct.getString("TotalArea"));
						

						if(rsAct.getString("Crop").startsWith("0"))
							ActRowObj2.put("plantationCode",rsAct.getString("Crop"));
						else
							ActRowObj2.put("plantationCode","0"+rsAct.getString("Crop"));

						ActRowArrObj2.add(ActRowObj2);
					}

					//stmtCrop.close();
					//rsCrop.close();
				}
				/*
				 * else if(activityType==2) { ActRowObj.put("landVillage", "058136");
				 * ActRowObj.put("plantationCode", "123"); ActRowObj.put("surveyNumber", "12");
				 * ActRowObj.put("khataNumber", 5); ActRowObj.put("plantationArea", 2);
				 * 
				 * } else if(activityType==3) { ActRowObj.put("landVillage", "058136");
				 * ActRowObj.put("liveStockType",1); ActRowObj.put("liveStockCode", 2);
				 * ActRowObj.put("unitCount", 23); } else if(activityType==4) {
				 * ActRowObj.put("landVillage", "058136"); ActRowObj.put("inlandType",1);
				 * ActRowObj.put("totalUnits", 12); ActRowObj.put("totalArea", 2); } else
				 * if(activityType==5) { ActRowObj.put("landVillage", "058136");
				 * ActRowObj.put("marineType",3); ActRowObj.put("totalUnits", 2); }
				 */

				//if(cropFlag)
					ActObj.put("activityRows", ActRowArrObj);
				
				//if(hort)
				{
					ActObj2.put("activityRows", ActRowArrObj2);
				}
				if(cropFlag)
					ActObjArrObj.add(ActObj);
				if(hort)
					ActObjArrObj.add(ActObj2);
				AppObj.put("activities", ActObjArrObj);

				//if(AccFlag)
				AppArr.add(AppObj);
				stmtAc.close();
				stmtLoan.close();
				stmtAct.close();
				rsAcc.close();
				rsLoan.close();
				rsAct.close();
			}


			if(flag)
			{
				//Remove for more than 1 batch upload
				//flag=false;
				Batch.put("applications",AppArr);
	
				abc = convertToJson(Batch);
				String reqEncrypt = "";
				try {
					//			String key = prop.getProperty("key");
					//			System.out.println("ddv " + key);
					reqEncrypt = Encryptor.encrypt(abc);
					dobj.setClientId(prop.getProperty("clientId"));
					dobj.setEncData(reqEncrypt);
	
					def = convertToJson(dobj);
	
					System.out.println("Req======"+abc);
	
					//System.out.println("Request Encrypted===="+def);
					StringEntity input = new StringEntity(def);
					input.setContentType("application/json");
					postreq.setEntity(input);
					//postreq.addHeader("AccessToken", key);
					CloseableHttpResponse res = httpClient.execute(postreq);
					HttpEntity entity = res.getEntity();
	
	
					String content = EntityUtils.toString(entity);
					System.out.println("Encrypted Response====="+content);
					
					JSONParser enparser = new JSONParser();  
					JSONObject enjson = (JSONObject) enparser.parse(content);  
					
					boolean enstatus=(boolean) enjson.get("status");
					//boolean enstatus=false;
					
					
					if(enstatus)
					{
						ObjectMapper mapper = new ObjectMapper();
						dobj = mapper.readValue(content, RequestDto.class);
						String decrypt = Encryptor.decrypt(dobj.getEncData());
						System.out.println("Decrypted Response====="+decrypt);
						
						JSONParser parser = new JSONParser();  
						JSONObject json = (JSONObject) parser.parse(decrypt);  
						System.out.println(al.size());
						Long status=(Long) json.get("status");
						if(status==1)
						{
							System.out.println("Inside if statement");
							String INSERT_USERS_SQL = "insert into loanflow.\"Batch_Processed\"" + "  (\"ApplicationId\",\"uniqueId\", \"BatchAckId\", \"ProcessedDate\") VALUES " +
									" (?, ?, ?, CURRENT_DATE);";
							PreparedStatement preparedStatement = c.prepareStatement(INSERT_USERS_SQL);
							Iterator<Applicant> it=al.iterator();
							while ( it.hasNext()) {
								System.out.println("Inside while statement");
								Applicant newApp=it.next();
								preparedStatement.setString(1, newApp.getApplicationId());
								preparedStatement.setString(2, newApp.getUniqueId());
								preparedStatement.setString(3, (String) json.get("batchAckId"));
								preparedStatement.addBatch();
							}
		
							//long start = System.currentTimeMillis();
							int[] inserted = preparedStatement.executeBatch();
							preparedStatement.close();
							//long end = System.currentTimeMillis();
						}
					
					}
					else
					{
						//System.out.println("Inside if statement");
						String INSERT_USERS_SQL = "insert into loanflow.\"Batch_Processed\"" + "  (\"ApplicationId\",\"uniqueId\", \"ProcessedDate\") VALUES " +
								" (?,?,  CURRENT_DATE);";
						PreparedStatement preparedStatement = c.prepareStatement(INSERT_USERS_SQL);
						Iterator<Applicant> it=al.iterator();
						while ( it.hasNext()) {
							//System.out.println("Inside while statement");
							Applicant newApp=it.next();
							preparedStatement.setString(1, newApp.getApplicationId());
							preparedStatement.setString(2, newApp.getUniqueId());
							preparedStatement.addBatch();
						}
	
						//long start = System.currentTimeMillis();
						int[] inserted = preparedStatement.executeBatch();
						preparedStatement.close();
					}
					rs.close();
	
					stmt.close();
	
					c.close();
					//return decrypt;
				} catch (Exception e) {
	
					e.printStackTrace();
					//return "{\"responseCode\":\"201\"}";
				}
			}
			else
			{
				System.out.println("No Data Available");
			}
		}
		return null;

	}

	public static String convertToJson(JSONObject vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	public static String convertToJson(RequestDto vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	


}
