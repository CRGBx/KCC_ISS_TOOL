package org.crgb.fasalbima.main;



import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.crgb.fasalbima.common.*;
import org.crgb.fasalbima.dbcom.*;
import org.crgb.fasalbima.obj.*;
import org.crgb.fasalbima.encryption.*;
public class GetDistrictList {
	  CloseableHttpClient httpClient = HttpClients.createDefault();
	public  String  DistrictList(String stateCOde,Properties prop) throws IOException {
		
		String abc = "";
		String def = "";
		
		StateObj dob = new StateObj();
		RequestDto dobj = new RequestDto();
		HttpPost postreq = new
				HttpPost("https://fasalrin.gov.in/v1/issintegration/districts");
		
		
		//dob.setRegnNo("HR03P8989");
		dob.setStateCode(stateCOde);
		
		abc = convertToJson(dob);
		String reqEncrypt = "";
		try {
//			String key = prop.getProperty("key");
//			System.out.println("ddv " + key);
			reqEncrypt = Encryptor.encrypt(abc);
			dobj.setClientId(prop.getProperty("clientId"));
			dobj.setEncData(reqEncrypt);
			
			def = convertToJson(dobj);
			
			System.out.println("Req======"+abc);
			
			System.out.println("Request Encrypted===="+def);
			StringEntity input = new StringEntity(def);
			input.setContentType("application/json");
			postreq.setEntity(input);
			//postreq.addHeader("AccessToken", key);
			CloseableHttpResponse res = httpClient.execute(postreq);
			HttpEntity entity = res.getEntity();
			String content = EntityUtils.toString(entity);
			System.out.println("Encrypted Response====="+content);
			ObjectMapper mapper = new ObjectMapper();
			dobj = mapper.readValue(content, RequestDto.class);
			String decrypt = Encryptor.decrypt(dobj.getEncData());
			System.out.println("Decrypted Response====="+decrypt);
			return decrypt;
		} catch (Exception e) {
			
			e.printStackTrace();
			return "{\"responseCode\":\"201\"}";
		}
		
	}
	

	public static String convertToJson(RequestDto vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	public static String convertToJson(StateObj vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}
	
	
}


