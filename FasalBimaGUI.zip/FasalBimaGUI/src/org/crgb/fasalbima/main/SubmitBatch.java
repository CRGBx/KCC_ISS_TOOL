package org.crgb.fasalbima.main;


import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Properties;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.crgb.fasalbima.common.*;
import org.crgb.fasalbima.dbcom.*;
import org.crgb.fasalbima.obj.*;
import org.crgb.fasalbima.encryption.*;
public class SubmitBatch {
	  CloseableHttpClient httpClient = HttpClients.createDefault();
	public  String  BatchProcessing(Properties prop) throws IOException, ParseException, SQLException {
		
		String abc = "";
		String def = "";
		
		RequestDto dobj = new RequestDto();
		HttpPost postreq = new
				HttpPost("https://fasalrin.gov.in/v1/issintegration/submitbatch");
		
		
		//dob.setRegnNo("HR03P8989");
		
		DBConnection db=new DBConnection();
		Connection c =db.ConnectionString(prop);
		Statement stmt = c.createStatement();
		
		BatchMainObj dob = new BatchMainObj();
		dob.setBatchId("21012306300021");
		dob.setFinancialYear("2021-2022");
		
		///application part
		ApplicationsObj appDob = new ApplicationsObj();
		appDob.setUniqueId("2101230630002100001");
		appDob.setRecordStatus("1");
		//String appStr=convertToJson(appDob);
		//dob.setApplications(appDob);
		///////Basic Detail
		BasicDetailObj basicDob=new BasicDetailObj();
		basicDob.setAadhaarNumber("878554203861");
		basicDob.setBeneficiaryName("Kushal Sengar");
		basicDob.setBeneficiaryPassbookName("Kushal Sengar");
		basicDob.setRelativeName("D N Singh");
		basicDob.setDob("1994-02-18");
		basicDob.setFarmerCategory(1);
		basicDob.setFarmerType(2);
		basicDob.setGender(1);
		basicDob.setMobile("7739197702");
		basicDob.setSocialCategory(2);
		basicDob.setPrimaryOccupation(1);
		basicDob.setRelativeType(1);
		//String basicStr=convertToJson(basicDob);
		appDob.setBasicDetails(basicDob);
		//////////////////////Residential
		ResidentialObj resObj=new ResidentialObj();
		resObj.setResidentialAddress("Sunder Nagar CG");
		resObj.setResidentialPincode("497231");
		resObj.setResidentialVillage("432801");
		String residentialStr=convertToJson(resObj);
		appDob.setResidentialDetails(resObj);
		////////////////////
		AccountObj accObj=new AccountObj();
		//accObj.setAccountType(1);
		accObj.setAccountNumber("77067740833");
		accObj.setIFSC("CRGB0000402");
		accObj.setBranchCode("120557");
		accObj.setAccountHolder(1);
		
		/////Joint Acc
//		JointAccObj jaObj=new JointAccObj();
//		jaObj.setAadhaarNumber("878554203861");
//		jaObj.setIsPrimary(1);
//		jaObj.setName("Kushal Sengar");
//		accObj.setJointAccountHolders(jaObj);
		
		String accStr=convertToJson(accObj);
		
	
		appDob.setAccountDetails(accObj);
		
		
		/////////////////////Loan Det
		SimpleDateFormat formatter=new SimpleDateFormat("yyyy-mm-dd");
		LoanDetObj loanObj=new LoanDetObj();
		loanObj.setKccLoanSanctionedDate("2022-06-17");
		loanObj.setKccLimitSanctionedAmount(5521);
		loanObj.setKccDrawingLimitForFY(50000);
		String loanStr=convertToJson(loanObj);
		appDob.setLoanDetails(loanObj);
		/////////////////////Activities
		ActivitesObj acObj=new ActivitesObj();
		acObj.setActivityType(1);
		acObj.setLoanSanctionedAmount(6666);
		acObj.setLoanSanctionedDate("2022-06-17");
		
		//////ActivityRow
		ActivityRows actRow=new ActivityRows();
		actRow.setCropCode("021000100");
		actRow.setLandArea(5);
		actRow.setLandType(1);
		actRow.setLandVillage("432801");
		actRow.setSeason(1);
		actRow.setKhataNumber("12");
		actRow.setSurveyNumber("123");
		acObj.setActivityRows(actRow);
		//String activityStr=convertToJson(acObj);
		appDob.setActivities(acObj);
		
		
		
		dob.setApplications(appDob);
		
		
		
		
		abc = convertToJson(dob);
		abc="{\"financialYear\":\"2021-2022\",\"batchId\":\"10022306300002\",\"applications\":[{\"recordStatus\":1,\"residentialDetails\":{\"residentialAddress\":\"Test Address\",\"residentialVillage\":\"432562\",\"residentialPincode\":\"495001\"},\"accountDetails\":{\"branchCode\":\"121003\",\"accountHolder\":1,\"accountNumber\":\"00000077071893318\",\"ifsc\":\"CRGB0006091\"},\"loanDetails\":{\"kccDrawingLimitForFY\":\"5725.00\",\"kccLimitSanctionedAmount\":\"5725.00\",\"kccLoanSanctionedDate\":\"2021-09-08\"},\"activities\":[{\"loanSanctionedDate\":\"2021-09-08\",\"activityType\":1,\"loanSanctionedAmount\":\"5725.00\",\"activityRows\":[{\"cropCode\":\"010420200\",\"landVillage\":\"432562\",\"khataNumber\":\"263/1\",\"landArea\":\"0.0900\",\"season\":1,\"surveyNumber\":\"263/1\",\"landType\":2}]}],\"basicDetails\":{\"relativeName\":\"SHOBNATH DAS\",\"aadhaarNumber\":\"824029627247\",\"gender\":1,\"beneficiaryName\":\"NAHKUL DAS\",\"dob\":\"1956-01-01\",\"mobile\":\"7739197702\",\"primaryOccupation\":1,\"socialCategory\":0,\"farmerType\":1,\"farmerCategory\":1,\"beneficiaryPassbookName\":\"NAHKUL DAS\",\"relativeType\":1},\"uniqueId\":\"1002230630000200001\"},{\"recordStatus\":1,\"residentialDetails\":{\"residentialAddress\":\"Test Address\",\"residentialVillage\":\"432562\",\"residentialPincode\":\"495001\"},\"accountDetails\":{\"branchCode\":\"121003\",\"accountHolder\":1,\"accountNumber\":\"00000077071914997\",\"ifsc\":\"CRGB0006091\"},\"loanDetails\":{\"kccDrawingLimitForFY\":\"7300.00\",\"kccLimitSanctionedAmount\":\"7300.00\",\"kccLoanSanctionedDate\":\"2021-09-08\"},\"activities\":[{\"loanSanctionedDate\":\"2021-09-08\",\"activityType\":1,\"loanSanctionedAmount\":\"7300.00\",\"activityRows\":[{\"cropCode\":\"010420200\",\"landVillage\":\"432562\",\"khataNumber\":\"658\",\"landArea\":\"0.1200\",\"season\":1,\"surveyNumber\":\"658\",\"landType\":2}]}],\"basicDetails\":{\"relativeName\":\"SHYAMLAL RAJWADE\",\"aadhaarNumber\":\"910452415870\",\"gender\":2,\"beneficiaryName\":\"URMILA RAJWADE\",\"dob\":null,\"mobile\":\"7739197702\",\"primaryOccupation\":1,\"socialCategory\":4,\"farmerType\":1,\"farmerCategory\":1,\"beneficiaryPassbookName\":\"URMILA RAJWADE\",\"relativeType\":3},\"uniqueId\":\"1002230630000200002\"},{\"recordStatus\":1,\"residentialDetails\":{\"residentialAddress\":\"Test Address\",\"residentialVillage\":\"432568\",\"residentialPincode\":\"495001\"},\"accountDetails\":{\"branchCode\":\"121003\",\"accountHolder\":1,\"accountNumber\":\"00000077072762340\",\"ifsc\":\"CRGB0006091\"},\"loanDetails\":{\"kccDrawingLimitForFY\":\"113700.00\",\"kccLimitSanctionedAmount\":\"125100.00\",\"kccLoanSanctionedDate\":\"2021-06-10\"},\"activities\":[{\"loanSanctionedDate\":\"2021-06-10\",\"activityType\":1,\"loanSanctionedAmount\":\"125100.00\",\"activityRows\":[{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"1110\",\"landArea\":\"0.3800\",\"season\":1,\"surveyNumber\":\"1110\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"1110\",\"landArea\":\"0.3000\",\"season\":1,\"surveyNumber\":\"1254\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"1110\",\"landArea\":\"0.1900\",\"season\":1,\"surveyNumber\":\"246\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"1110\",\"landArea\":\"0.1800\",\"season\":1,\"surveyNumber\":\"1168\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"1110\",\"landArea\":\"0.1800\",\"season\":1,\"surveyNumber\":\"257\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"1110\",\"landArea\":\"0.1700\",\"season\":1,\"surveyNumber\":\"3083\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"1110\",\"landArea\":\"0.1400\",\"season\":1,\"surveyNumber\":\"1322\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"1110\",\"landArea\":\"0.1100\",\"season\":1,\"surveyNumber\":\"1210\",\"landType\":2},{\"cropCode\":\"011517400\",\"landVillage\":\"432568\",\"khataNumber\":\"1110\",\"landArea\":\"0.0600\",\"season\":1,\"surveyNumber\":\"916\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"1110\",\"landArea\":\"0.0200\",\"season\":1,\"surveyNumber\":\"919\",\"landType\":2}]}],\"basicDetails\":{\"relativeName\":\"SOBHIT RAM\",\"aadhaarNumber\":\"773302025418\",\"gender\":1,\"beneficiaryName\":\"DHARAM SAY\",\"dob\":\"1976-04-01\",\"mobile\":\"7739197702\",\"primaryOccupation\":1,\"socialCategory\":2,\"farmerType\":1,\"farmerCategory\":1,\"beneficiaryPassbookName\":\"DHARAM SAY\",\"relativeType\":1},\"uniqueId\":\"1002230630000200003\"},{\"recordStatus\":1,\"residentialDetails\":{\"residentialAddress\":\"Test Address\",\"residentialVillage\":\"432564\",\"residentialPincode\":\"495001\"},\"accountDetails\":{\"branchCode\":\"121003\",\"accountHolder\":1,\"accountNumber\":\"00000077078989706\",\"ifsc\":\"CRGB0006091\"},\"loanDetails\":{\"kccDrawingLimitForFY\":\"46400.00\",\"kccLimitSanctionedAmount\":\"51000.00\",\"kccLoanSanctionedDate\":\"2021-07-01\"},\"activities\":[{\"loanSanctionedDate\":\"2021-07-01\",\"activityType\":1,\"loanSanctionedAmount\":\"51000.00\",\"activityRows\":[{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.1500\",\"season\":1,\"surveyNumber\":\"962\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.1200\",\"season\":1,\"surveyNumber\":\"961\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.1200\",\"season\":1,\"surveyNumber\":\"419\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.1100\",\"season\":1,\"surveyNumber\":\"851\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.1100\",\"season\":1,\"surveyNumber\":\"1086\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.1100\",\"season\":1,\"surveyNumber\":\"1084\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.1100\",\"season\":1,\"surveyNumber\":\"1082\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.0800\",\"season\":1,\"surveyNumber\":\"699\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.0800\",\"season\":1,\"surveyNumber\":\"703\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.0700\",\"season\":1,\"surveyNumber\":\"417\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.0500\",\"season\":1,\"surveyNumber\":\"449\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.0500\",\"season\":1,\"surveyNumber\":\"451\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.0500\",\"season\":1,\"surveyNumber\":\"982\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.0500\",\"season\":1,\"surveyNumber\":\"414\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.0400\",\"season\":1,\"surveyNumber\":\"444\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.0400\",\"season\":1,\"surveyNumber\":\"351\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.0400\",\"season\":1,\"surveyNumber\":\"694\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.0300\",\"season\":1,\"surveyNumber\":\"453\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.0300\",\"season\":1,\"surveyNumber\":\"978\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432564\",\"khataNumber\":\"962\",\"landArea\":\"0.0300\",\"season\":1,\"surveyNumber\":\"1116\",\"landType\":2}]}],\"basicDetails\":{\"relativeName\":\"GUTHAL RAM\",\"aadhaarNumber\":\"264630560630\",\"gender\":1,\"beneficiaryName\":\"KHEM SAI  SAI\",\"dob\":\"1967-01-01\",\"mobile\":\"7739197702\",\"primaryOccupation\":1,\"socialCategory\":0,\"farmerType\":1,\"farmerCategory\":1,\"beneficiaryPassbookName\":\"KHEM SAI SAI\",\"relativeType\":1},\"uniqueId\":\"1002230630000200004\"},{\"recordStatus\":1,\"residentialDetails\":{\"residentialAddress\":\"Test Address\",\"residentialVillage\":\"432565\",\"residentialPincode\":\"495001\"},\"accountDetails\":{\"branchCode\":\"121003\",\"accountHolder\":1,\"accountNumber\":\"00000077080545314\",\"ifsc\":\"CRGB0006091\"},\"loanDetails\":{\"kccDrawingLimitForFY\":\"52200.00\",\"kccLimitSanctionedAmount\":\"52200.00\",\"kccLoanSanctionedDate\":\"2021-09-04\"},\"activities\":[{\"loanSanctionedDate\":\"2021-09-04\",\"activityType\":1,\"loanSanctionedAmount\":\"52200.00\",\"activityRows\":[{\"cropCode\":\"010420200\",\"landVillage\":\"432565\",\"khataNumber\":\"51/1\",\"landArea\":\"0.3600\",\"season\":1,\"surveyNumber\":\"51/1\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432565\",\"khataNumber\":\"51/1\",\"landArea\":\"0.1900\",\"season\":1,\"surveyNumber\":\"52/1\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432565\",\"khataNumber\":\"51/1\",\"landArea\":\"0.1400\",\"season\":1,\"surveyNumber\":\"50/1\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432565\",\"khataNumber\":\"51/1\",\"landArea\":\"0.1100\",\"season\":1,\"surveyNumber\":\"53/1\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432565\",\"khataNumber\":\"51/1\",\"landArea\":\"0.1000\",\"season\":1,\"surveyNumber\":\"49/1\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432565\",\"khataNumber\":\"51/1\",\"landArea\":\"0.0800\",\"season\":1,\"surveyNumber\":\"98/1\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432565\",\"khataNumber\":\"51/1\",\"landArea\":\"0.0500\",\"season\":1,\"surveyNumber\":\"243/1\",\"landType\":2}]}],\"basicDetails\":{\"relativeName\":\"MAHENDRA GOND\",\"aadhaarNumber\":\"659543523411\",\"gender\":2,\"beneficiaryName\":\"DHANMET DHANSAI\",\"dob\":null,\"mobile\":\"7739197702\",\"primaryOccupation\":1,\"socialCategory\":2,\"farmerType\":1,\"farmerCategory\":1,\"beneficiaryPassbookName\":\"DHANMET DHANSAI\",\"relativeType\":3},\"uniqueId\":\"1002230630000200005\"},{\"recordStatus\":1,\"residentialDetails\":{\"residentialAddress\":\"Test Address\",\"residentialVillage\":\"432568\",\"residentialPincode\":\"495001\"},\"accountDetails\":{\"branchCode\":\"121003\",\"accountHolder\":1,\"accountNumber\":\"00000077081690281\",\"ifsc\":\"CRGB0006091\"},\"loanDetails\":{\"kccDrawingLimitForFY\":\"61200.00\",\"kccLimitSanctionedAmount\":\"61200.00\",\"kccLoanSanctionedDate\":\"2021-10-28\"},\"activities\":[{\"loanSanctionedDate\":\"2021-10-28\",\"activityType\":1,\"loanSanctionedAmount\":\"61200.00\",\"activityRows\":[{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"2620\",\"landArea\":\"0.2600\",\"season\":1,\"surveyNumber\":\"2620\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"2620\",\"landArea\":\"0.2600\",\"season\":1,\"surveyNumber\":\"1200\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"2620\",\"landArea\":\"0.2000\",\"season\":1,\"surveyNumber\":\"3090\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"2620\",\"landArea\":\"0.1700\",\"season\":1,\"surveyNumber\":\"1452\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"2620\",\"landArea\":\"0.1600\",\"season\":1,\"surveyNumber\":\"1496\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"2620\",\"landArea\":\"0.1300\",\"season\":1,\"surveyNumber\":\"1297/2\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"2620\",\"landArea\":\"0.0800\",\"season\":1,\"surveyNumber\":\"1528\",\"landType\":2},{\"cropCode\":\"010420200\",\"landVillage\":\"432568\",\"khataNumber\":\"2620\",\"landArea\":\"0.0500\",\"season\":1,\"surveyNumber\":\"749\",\"landType\":2}]}],\"basicDetails\":{\"relativeName\":\"MITHURAM PORTE\",\"aadhaarNumber\":\"317970957288\",\"gender\":1,\"beneficiaryName\":\"SHRIRAM PORTE\",\"dob\":\"1961-01-01\",\"mobile\":\"7739197702\",\"primaryOccupation\":1,\"socialCategory\":2,\"farmerType\":1,\"farmerCategory\":1,\"beneficiaryPassbookName\":\"SHRIRAM PORTE\",\"relativeType\":1},\"uniqueId\":\"1002230630000200006\"}]}";
		String reqEncrypt = "";
		try {
//			String key = prop.getProperty("key");
//			System.out.println("ddv " + key);
			reqEncrypt = Encryptor.encrypt(abc);
			dobj.setClientId(prop.getProperty("clientId"));
			dobj.setEncData(reqEncrypt);
			
			def = convertToJson(dobj);
			//def="{\"authCode\":\" aa532da7-d6ef-477e-80d2-04bd640f7400\",\"data\":{\"batchId\":\"20012306301287\",\"financialYear\":\"2022-2023\",\"applications\":[{\"uniqueId\":\"20012306301287513721\",\"recordStatus\":1,\"basicDetails\":{\"beneficiaryName\":\"SURLA TATA BABU\",\"aadhaarNumber\":\"944803473589\",\"beneficiaryPassbookName\":\"SURLA TATA BABU\",\"mobile\":\"9959931416\",\"dob\":\"1976-01-31\",\"gender\":1,\"socialCategory\":2,\"farmerCategory\":1,\"farmerType\":2,\"primaryOccupation\":1,\"relativeType\":1,\"relativeName\":\"VENKANNA\"},\"residentialDetails\":{\"residentialVillage\":\"432801\",\"residentialAddress\":\". KONDALAAGRAHARAM AP\",\"residentialPincode\":\"497231\"},\"accountDetails\":{\"accountNumber\":\"77067740833\",\"branchCode\":\"120557\",\"ifsc\":\"CRGB0000402\",\"accountHolder\":1},\"loanDetails\":{\"kccLoanSanctionedDate\":\"2022-12-22\",\"kccLimitSanctionedAmount\":80000,\"kccDrawingLimitForFY\":80000},\"activities\":[{\"activityType\":1,\"loanSanctionedDate\":\"2022-12-22\",\"loanSanctionedAmount\":80000,\"activityRows\":[{\"landVillage\":\"432801\",\"cropCode\":\"022028304\",\"surveyNumber\":\"NA\",\"khataNumber\":\"452\",\"landArea\":0.53009,\"landType\":1,\"season\":2}]}]}]}}";
			System.out.println("Req======"+abc);
			
			System.out.println("Request Encrypted===="+def);
			StringEntity input = new StringEntity(def);
			input.setContentType("application/json");
			postreq.setEntity(input);
			//postreq.addHeader("AccessToken", key);
			CloseableHttpResponse res = httpClient.execute(postreq);
			HttpEntity entity = res.getEntity();
			String content = EntityUtils.toString(entity);
			System.out.println("Encrypted Response====="+content);
			ObjectMapper mapper = new ObjectMapper();
			dobj = mapper.readValue(content, RequestDto.class);
			String decrypt = Encryptor.decrypt(dobj.getEncData());
			System.out.println("Decrypted Response====="+decrypt);
			return decrypt;
		} catch (Exception e) {
			
			e.printStackTrace();
			return "{\"responseCode\":\"201\"}";
		}
		
	}
	
	private String convertToJson(ActivitesObj vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	private String convertToJson(LoanDetObj vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	private String convertToJson(AccountObj vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	private String convertToJson(ResidentialObj vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	private String convertToJson(BasicDetailObj vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	public static String convertToJson(RequestDto vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	public static String convertToJson(BatchMainObj vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	public static String convertToJson(ApplicationsObj vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}
	
	
}


