package org.crgb.fasalbima.main;

import java.awt.TextArea;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.crgb.fasalbima.common.*;
import org.crgb.fasalbima.dbcom.*;
import org.crgb.fasalbima.obj.*;
import org.crgb.fasalbima.encryption.*;
public class ISClaim {
	CloseableHttpClient httpClient = HttpClients.createDefault();
	public  String  BatchProcessing(Properties prop,String fy,int batchCount,TextArea textArea) throws IOException, ParseException, SQLException {

		String abc = "";
		String def = "";
		

		RequestDto dobj = new RequestDto();
		HttpPost postreq = new
				HttpPost(prop.getProperty("submit_claim_batch_url"));
		
		//"https://fasalrin.gov.in/v1/issintegration/submitclaimbatch"


		//dob.setRegnNo("HR03P8989");
		boolean flag=true;
		//int batchCount=1;
		
		while(flag)
		{
			flag=false;
			Date dateNow = new Date();

			//change date into string yyyyMMdd format example "20110914"
			SimpleDateFormat dateformatyyyyMMdd = new SimpleDateFormat("ddMMyy");
			String date_to_string = dateformatyyyyMMdd.format(dateNow);
			
			JSONObject Batch=new JSONObject();
			String basicId=date_to_string+"063";
			String batchId=basicId+"0000"+batchCount;
			if(batchCount>9&&batchCount<100)
				batchId=basicId+"000"+batchCount;
			else if(batchCount>99&&batchCount<1000)
				batchId=basicId+"00"+batchCount;
			else if(batchCount>999)
				batchId=basicId+"0"+batchCount;
			
			batchCount++;
			Batch.put("batchId",batchId);
			
			String FinacialYear=fy.replaceAll("_", "-");
			
			Batch.put("financialYear", FinacialYear);
			JSONArray AppArr=new JSONArray();


			DBConnection db=new DBConnection();
			Connection c =db.ConnectionString(prop);
			Statement stmt = c.createStatement();


			String sql = "select a.*,b.* from kcc_iss.\"Batch_Processed_"+fy+"\" a join kcc_iss.kcc_iss_claim_2022_23 b on a.\"ApplicationId\"=b.\"ApplicationId\" join "
					+ "kcc_iss.kcc_iss_bank_clain_cy c on \"SUB_ACC_NO\"=b.\"ApplicationId\" where \"Status\"='1'  and \"isDeleted\" isnull and not exists "
					+ "(select 1 from kcc_iss.\"KCC_ISS_CLAIM_BATCH_PROCESSED_"+fy+"\" d where d.\"LoanAppplicationNumber\"=a.\"LoanAppplicationNumber\" "
					+ "and \"isDeleted\" isnull) and bank_pri_claim =0 and bank_iss_claim!=0 limit 1000;";
//					+ "inner join kcc_iss.\"Account_Details\" j on i.\"ApplicationId\"=j.\"ApplicationId\"\r\n"
//					+ "where \"accountHolder\"=1 limit 1000";
			
			System.out.println("Basic Details==="+sql);
			textArea.append("\nBasic Details==="+sql);
			ResultSet rs = stmt.executeQuery( sql );


			int count=1;
			

			ArrayList<Applicant> al=new ArrayList<Applicant>();
			while ( rs.next() ) {
				flag=true;
				JSONObject AppObj=new JSONObject();
				JSONObject priObj=new JSONObject();

				Statement stmtAc = c.createStatement();
				Statement stmtLoan = c.createStatement();

				Statement stmtAct = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				//System.out.println(count);

				//String loanDet = "select * from kcc_iss.\"Loan_Details\" where \"ApplicationId\"='"+rs.getString("ApplicationId")+"'";
				

				//System.out.println("Loan Details==="+loanDet);

				

//				ResultSet rsLoan = stmtLoan.executeQuery( loanDet );
//				rsLoan.next();



				

				String uniqueId=batchId+"0000"+count;
				if(count>9&&count<100)
					uniqueId=batchId+"000"+count;
				else if(count>99&&count<1000)
					uniqueId=batchId+"00"+count;
				else if(count>999)
					uniqueId=batchId+"0"+count;
				AppObj.put("uniqueId", uniqueId);
				count++;
				
				Applicant app=new Applicant();
				app.setApplicationId(rs.getString("LoanAppplicationNumber"));
				app.setUniqueId(uniqueId);
				

				AppObj.put("loanApplicationNumber", rs.getString("LoanAppplicationNumber"));
				AppObj.put("claimType", "IS");
				AppObj.put("submissionType", 2);
				AppObj.put("firstLoanDisbursalDate", rs.getString("loanSanctionedDate"));
				AppObj.put("loanRepaymentDate", rs.getString("loanRepaymentDate"));
				
				double maxWithdrawlAmount=rs.getDouble("sanctionedAmount")>rs.getDouble("totalDebit")?rs.getDouble("totalDebit"):rs.getDouble("sanctionedAmount");
				AppObj.put("maxWithdrawalAmount", maxWithdrawlAmount);
				AppObj.put("applicableISAmount", rs.getDouble("actual_bank_iss_claim"));
				
				
				app.setClaimAmount(rs.getDouble("bank_iss_claim"));
				al.add(app);
				AppArr.add(AppObj);
//				if(rs.getString("isClosed").equals("Y"))
//				{
//					 uniqueId=batchId+"0000"+count;
//					if(count>9&&count<100)
//						uniqueId=batchId+"000"+count;
//					else if(count>99&&count<1000)
//						uniqueId=batchId+"00"+count;
//					else if(count>999)
//						uniqueId=batchId+"0"+count;
//					count++;
//					
//					priObj.put("uniqueId", uniqueId);
//					priObj.put("loanApplicationNumber", rs.getString("LoanAppplicationNumber"));
//					priObj.put("claimType", "PRI");
//					priObj.put("isEligibleForPRI", 0);
//					app=new Applicant();
//					app.setApplicationId(rs.getString("LoanAppplicationNumber"));
//					app.setClaimAmount(0);
//					app.setUniqueId(uniqueId);
//					
//					al.add(app);
//					AppArr.add(priObj);
//				}

				

				

				//if(AccFlag)
				
				stmtAc.close();
				stmtLoan.close();
				stmtAct.close();
			}


			if(flag)
			{
				//Remove for more than 1 batch upload
				//flag=false;
				Batch.put("applications",AppArr);
				
				
	
				abc = convertToJson(Batch);
				String reqEncrypt = "";
				String INSERT_USERS_SQL_activity = "insert into kcc_iss.kcc_iss_claim_submitted_req_res  (\"batch_id\",\"upload_date\", \"req\", \"res\") VALUES " +
						" (?, CURRENT_DATE,?,?);";
				PreparedStatement preparedStatement2 = c.prepareStatement(INSERT_USERS_SQL_activity);
				try {
					//			String key = prop.getProperty("key");
					//			System.out.println("ddv " + key);
					reqEncrypt = Encryptor.encrypt(abc);
					dobj.setClientId(prop.getProperty("clientId"));
					dobj.setEncData(reqEncrypt);
	
					def = convertToJson(dobj);
	
					System.out.println("Req======"+abc);
					textArea.append("\nReq======"+abc);
					
					preparedStatement2.setString(1, batchId);
					preparedStatement2.setString(2, abc);
	
					//System.out.println("Request Encrypted===="+def);
					StringEntity input = new StringEntity(def);
					input.setContentType("application/json");
					postreq.setEntity(input);
					//postreq.addHeader("AccessToken", key);
					CloseableHttpResponse res = httpClient.execute(postreq);
					HttpEntity entity = res.getEntity();
	
	
					String content = EntityUtils.toString(entity);
					System.out.println("Encrypted Response====="+content);
					textArea.append("\nEncrypted Response====="+content);
					preparedStatement2.setString(3, content);
					
					JSONParser enparser = new JSONParser();  
					JSONObject enjson = (JSONObject) enparser.parse(content);  
					
					boolean enstatus=(boolean) enjson.get("status");
					//boolean enstatus=false;
					
					if(enstatus)
					{
						ObjectMapper mapper = new ObjectMapper();
						dobj = mapper.readValue(content, RequestDto.class);
						String decrypt = Encryptor.decrypt(dobj.getEncData());
						//System.out.println("Decrypted Response====="+decrypt);
						preparedStatement2.setString(3, decrypt);

						JSONParser parser = new JSONParser();  
						JSONObject json = (JSONObject) parser.parse(decrypt);  
						System.out.println(al.size());
						Long status=(Long) json.get("status");
						if(status==1)
						{
							//System.out.println("Inside if statement");
							String INSERT_USERS_SQL = "insert into kcc_iss.\"KCC_ISS_CLAIM_BATCH_PROCESSED_"+fy+"\"" + "  (\"LoanAppplicationNumber\",\"uniqueId\", \"ClaimDate\",\"ClaimAmount\",\"BatchAckId\") VALUES " +
									" (?,?,  CURRENT_DATE,?,?);";
							PreparedStatement preparedStatement = c.prepareStatement(INSERT_USERS_SQL);
							Iterator<Applicant> it=al.iterator();
							while ( it.hasNext()) {
								//System.out.println("Inside while statement");
								Applicant newApp=it.next();
								preparedStatement.setString(1, newApp.getApplicationId());
								preparedStatement.setString(2, newApp.getUniqueId());
								preparedStatement.setDouble(3, newApp.getClaimAmount());
								preparedStatement.setString(4, (String) json.get("batchAckId"));
								preparedStatement.addBatch();
							}
		

							//long start = System.currentTimeMillis();
							int[] inserted = preparedStatement.executeBatch();
							preparedStatement.close();
							//long end = System.currentTimeMillis();
						}

					}
					else
					{
						//System.out.println("Inside if statement");
						String INSERT_USERS_SQL = "insert into kcc_iss.\"KCC_ISS_CLAIM_BATCH_PROCESSED_"+fy+"\"" + "  (\"LoanAppplicationNumber\",\"uniqueId\", \"ClaimDate\",\"ClaimAmount\") VALUES " +
								" (?,?,  CURRENT_DATE,?);";
						PreparedStatement preparedStatement = c.prepareStatement(INSERT_USERS_SQL);
						Iterator<Applicant> it=al.iterator();
						while ( it.hasNext()) {
							//System.out.println("Inside while statement");
							Applicant newApp=it.next();
							preparedStatement.setString(1, newApp.getApplicationId());
							preparedStatement.setString(2, newApp.getUniqueId());
							preparedStatement.setDouble(2, newApp.getClaimAmount());
							preparedStatement.addBatch();
						}
	

						//long start = System.currentTimeMillis();
						int[] inserted = preparedStatement.executeBatch();
						preparedStatement.close();
					}
					preparedStatement2.addBatch();
					int[] inserted2 = preparedStatement2.executeBatch();
					preparedStatement2.close();
					rs.close();
	
					stmt.close();
	
					c.close();
					return "{\"responseCode\":\"200\"}";
					//return decrypt;
				} catch (Exception e) {
					preparedStatement2.addBatch();
					int[] inserted2 = preparedStatement2.executeBatch();
					preparedStatement2.close();
					rs.close();
					
					stmt.close();
	
					c.close();
					e.printStackTrace();
					return "{\"responseCode\":\"201\"}";
				}
			}
			else
			{
				System.out.println("No Data Available");
				textArea.append("\nNo Data Available");
			}
		}
		return "{\"responseCode\":\"200\"}";

	}

	public static String convertToJson(JSONObject vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	public static String convertToJson(RequestDto vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	


}
