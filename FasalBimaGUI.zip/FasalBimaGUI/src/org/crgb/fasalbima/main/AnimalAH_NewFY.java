package org.crgb.fasalbima.main;

import java.awt.TextArea;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.crgb.fasalbima.common.*;
import org.crgb.fasalbima.dbcom.*;
import org.crgb.fasalbima.obj.*;
import org.crgb.fasalbima.encryption.*;

import com.fasterxml.jackson.databind.ObjectMapper;

public class AnimalAH_NewFY {
	CloseableHttpClient httpClient = HttpClients.createDefault();
	public  String  BatchProcessing(Properties prop, String fy, int batchCount, TextArea textArea) throws IOException, ParseException, SQLException {

		String abc = "";
		String def = "";
		

		RequestDto dobj = new RequestDto();
		HttpPost postreq = new
				HttpPost(prop.getProperty("submit_batch_url"));


		//dob.setRegnNo("HR03P8989");
		boolean flag=true;
		//boolean flag1=true;
		

		while(flag)
		{
			 flag=false;
			 Date dateNow = new Date();

				//change date into string yyyyMMdd format example "20110914"
				SimpleDateFormat dateformatyyyyMMdd = new SimpleDateFormat("ddMMyy");
				String date_to_string = dateformatyyyyMMdd.format(dateNow);
				
			JSONObject Batch=new JSONObject();
			String basicId=date_to_string+"063";
			String batchId=basicId+"0000"+batchCount;
			if(batchCount>9&&batchCount<100)
				batchId=basicId+"000"+batchCount;
			else if(batchCount>99&&batchCount<1000)
				batchId=basicId+"00"+batchCount;
			else if(batchCount>999)
				batchId=basicId+"0"+batchCount;

			batchCount++;
			Batch.put("batchId",batchId);
			Batch.put("financialYear", "2022-2023");
			JSONArray AppArr=new JSONArray();


			DBConnection db=new DBConnection();
			Connection c =db.ConnectionString(prop);
			Statement stmt = c.createStatement();


			String sql = "SELECT a.\"ApplicationId\", \"beneficiaryName\", \"aadhaarNumber\", \"beneficiaryPassbookName\", \r\n"
					+ "a.mobile, dob, gender, \"socialCategory\", \"farmerCategory\", \"farmerType\", \"primaryOccupation\", \"relativeType\",residential_vill, \"relativeName\",pincode,address \r\n"
					+ "FROM kcc_iss.\"Basic_Details\" a inner join kcc_iss.kcc_iss_bank_claim_"+fy+" b on \"ApplicationId\"=lpad(\"SUB_ACC_NO\",17,'0') \r\n"
					+ "where type='ah' and \r\n"
					+ " not exists (select 1 from kcc_iss.\"Batch_Processed_"+fy+"\" d where d.\"ApplicationId\"=a.\"ApplicationId\" and \"isDeleted\" isnull)  limit 1000";
//					+ ""
//					+ "\r\n"
//					+ "inner join kcc_iss.\"Account_Details\" j on i.\"ApplicationId\"=j.\"ApplicationId\"\r\n"
//					+ "where \"accountHolder\"=1 limit 1000";
			//String sql="select * from kcc_iss.\"Basic_Details\" where \"ApplicationId\"='00000077084728521'";

			System.out.println("Basic Details==="+sql);
			textArea.append("\nBasic Details==="+sql);

			ResultSet rs = stmt.executeQuery( sql );


			int count=1;


			ArrayList<Applicant> al=new ArrayList<Applicant>();
			while ( rs.next() ) {
				flag=true;
				JSONObject AppObj=new JSONObject();

				Statement stmtAc = c.createStatement();
				Statement stmtLoan = c.createStatement();

				Statement stmtAct = c.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				//System.out.println(count);

				String accDet = "SELECT a.*,b.\"branchCode\" as \"brCode\" FROM kcc_iss.\"Account_Details\" a inner join kcc_iss.kcc_master_branch b on a.ifsc=b.\"ifscCode\" where \"ApplicationId\"='"+rs.getString("ApplicationId")+"'";
				String loanDet = "select * from kcc_iss.\"Loan_Details_"+fy+"\" where \"ApplicationId\"='"+rs.getString("ApplicationId")+"'";
				String actDet = "select * from kcc_iss.\"KCC_ISS_ACTIVITY_"+fy+"\" where \"ApplicationId\"='"+rs.getString("ApplicationId")+"'";

				System.out.println("\n\nAcc Details==="+accDet);
				System.out.println("Loan Details==="+loanDet);
				System.out.println("Act Details==="+actDet);
				
				textArea.append("\nAcc Details==="+accDet);
				textArea.append("\nLoan Details==="+loanDet);
				textArea.append("\nAct Details==="+actDet);

				ResultSet rsAcc = stmtAc.executeQuery( accDet );
				rsAcc.next();

				ResultSet rsLoan = stmtLoan.executeQuery( loanDet );
				rsLoan.next();

				ResultSet rsAct = stmtAct.executeQuery( actDet );
				rsAct.next();





				String uniqueId=batchId+"0000"+count;
				if(count>9&&count<100)
					uniqueId=batchId+"000"+count;
				else if(count>99&&count<1000)
					uniqueId=batchId+"00"+count;
				else if(count>999)
					uniqueId=batchId+"0"+count;
				AppObj.put("uniqueId", uniqueId);
				count++;
				Applicant app=new Applicant();
				app.setApplicationId(rs.getString("ApplicationId"));
				app.setUniqueId(uniqueId);
				al.add(app);
				AppObj.put("recordStatus", 1);

				JSONObject BasicObj=new JSONObject();
				BasicObj.put("beneficiaryName", rs.getString("beneficiaryName"));
				BasicObj.put("aadhaarNumber", rs.getString("aadhaarNumber"));
				BasicObj.put("beneficiaryPassbookName", rs.getString("beneficiaryName"));
				BasicObj.put("mobile",rs.getString("mobile"));
				BasicObj.put("dob", rs.getString("dob"));
				BasicObj.put("gender", rs.getInt("gender"));
				BasicObj.put("farmerCategory", rs.getInt("farmerCategory"));
				BasicObj.put("farmerType", rs.getInt("farmerType"));
				BasicObj.put("primaryOccupation", rs.getInt("primaryOccupation"));
				BasicObj.put("relativeType", rs.getInt("relativeType"));
				BasicObj.put("relativeName", rs.getString("relativeName"));
				BasicObj.put("socialCategory", rs.getInt("socialCategory"));
				AppObj.put("basicDetails", BasicObj);

				JSONObject ResObj=new JSONObject();
				//will be changed
				ResObj.put("residentialVillage", rs.getString("residential_vill"));
				ResObj.put("residentialAddress", rs.getString("address"));
				ResObj.put("residentialPincode", rs.getString("pincode"));
				AppObj.put("residentialDetails", ResObj);

				JSONObject AccObj=new JSONObject();
				AccObj.put("accountNumber", rsAcc.getString("accountNumber"));
				AccObj.put("branchCode", rsAcc.getString("brCode"));
				int accountHolder=rsAcc.getInt("accountHolder");

				AccObj.put("accountHolder", rsAcc.getInt("accountHolder"));
				accountHolder=rsAcc.getInt("accountHolder");
				AccObj.put("ifsc", rsAcc.getString("ifsc"));

				if(accountHolder>1)
				{
					JSONArray JointArrObj=new JSONArray();
					for(int i=0;i<accountHolder;i++)
					{
						JSONObject JointObj=new JSONObject();
						JointObj.put("name", rs.getString("beneficiaryName"));
						JointObj.put("aadhaarNumber", rs.getString("aadhaarNumber"));


						if(i>0)
						{
							JointObj.put("isPrimary", 0);
						}
						else
						{
							JointObj.put("isPrimary", 1);
						}

						JointArrObj.add(JointObj);
					}




					AccObj.put("jointAccountHolders", JointArrObj);
				}
				AppObj.put("accountDetails", AccObj);

				JSONObject LoanObj=new JSONObject();
				LoanObj.put("kccLoanSanctionedDate", rsLoan.getString("kccLoanSanctionedDate"));
//				if( Float.valueOf(rsLoan.getString("odlimit"))<Float.valueOf(rsLoan.getString("odlimit")))
//					LoanObj.put("kccLimitSanctionedAmount", rsLoan.getString("odlimit"));
//				else
					LoanObj.put("kccLimitSanctionedAmount", rsLoan.getString("kccLoanSanctionedAmount"));


				LoanObj.put("kccDrawingLimitForFY", rsLoan.getString("kccLoanSanctionedDate"));
				AppObj.put("loanDetails", LoanObj);

				JSONArray ActObjArrObj=new JSONArray();

				JSONObject ActObj=new JSONObject();
				JSONObject ActObj2=new JSONObject();
				ActObj.put("activityType", 3);
				ActObj2.put("activityType", 4);
				ActObj.put("loanSanctionedDate", rsLoan.getString("kccLoanSanctionedDate"));
				ActObj2.put("loanSanctionedDate", rsLoan.getString("kccLoanSanctionedDate"));
//				if( Float.valueOf(rsLoan.getString("kccDrawingLimitforFY"))<Float.valueOf(rsLoan.getString("kccLoanSanctionedAmount")))
//				{
//					ActObj.put("loanSanctionedAmount", rsLoan.getString("kccDrawingLimitforFY"));
//					ActObj2.put("loanSanctionedAmount", rsLoan.getString("kccDrawingLimitforFY"));
//				}
//				else
//				{
					ActObj.put("loanSanctionedAmount", rsLoan.getString("kccDrawingLimitforFY"));
					ActObj2.put("loanSanctionedAmount", rsLoan.getString("kccDrawingLimitforFY"));
//				}

				//ActObj.put("loanSanctionedAmount", rsLoan.getString("kccLoanSanctionedAmount"));

				JSONArray ActRowArrObj=new JSONArray();
				JSONArray ActRowArrObj2=new JSONArray();


				int activityType=1;

				int ActCount=0;
				String khataNumber="";
				boolean AccFlag=true;

				rsAct.beforeFirst();
				boolean ah=false;
				boolean fish=false;
				while(rsAct.next())
				{
					if(rsAct.getInt("ActivityType")==3)
					{
						ah=true;
						JSONObject ActRowObj=new JSONObject();
						
						ActRowObj.put("landVillage", rs.getString("residential_vill"));
						ActRowObj.put("liveStockType", rsAct.getString("liveStockType"));
						ActRowObj.put("liveStockCode",rsAct.getString("liveStockCode") );
						ActRowObj.put("unitCount", rsAct.getString("unitCount"));
						

						ActRowArrObj.add(ActRowObj);
					}
					else
					{
						fish=true;
						JSONObject ActRowObj2=new JSONObject();
						ActRowObj2.put("landVillage", rs.getString("residential_vill"));
						ActRowObj2.put("inlandType", rsAct.getString("inlandType"));
						ActRowObj2.put("totalUnits",rsAct.getString("totalUnits") );
						ActRowObj2.put("totalArea", rsAct.getString("TotalArea"));

						ActRowArrObj2.add(ActRowObj2);
					}
				}
				

				//if(cropFlag)
					ActObj.put("activityRows", ActRowArrObj);
				
				//if(hort)
				{
					ActObj2.put("activityRows", ActRowArrObj2);
				}
				if(ah)
					ActObjArrObj.add(ActObj);
				if(fish)
					ActObjArrObj.add(ActObj2);
				AppObj.put("activities", ActObjArrObj);

				//if(AccFlag)
				AppArr.add(AppObj);
				stmtAc.close();
				stmtLoan.close();
				stmtAct.close();
				rsAcc.close();
				rsLoan.close();
				rsAct.close();
			}


			if(flag)
			{
				//Remove for more than 1 batch upload
				//flag=false;
				Batch.put("applications",AppArr);

				abc = convertToJson(Batch);
				String reqEncrypt = "";
				try {
					//			String key = prop.getProperty("key");
					//			System.out.println("ddv " + key);
					reqEncrypt = Encryptor.encrypt(abc);
					dobj.setClientId(prop.getProperty("clientId"));
					dobj.setEncData(reqEncrypt);

					def = convertToJson(dobj);

					System.out.println("Req======"+abc);
					textArea.append("\nReq======"+abc);

					//System.out.println("Request Encrypted===="+def);
					StringEntity input = new StringEntity(def);
					input.setContentType("application/json");
					postreq.setEntity(input);
					//postreq.addHeader("AccessToken", key);
					CloseableHttpResponse res = httpClient.execute(postreq);
					HttpEntity entity = res.getEntity();


					String content = EntityUtils.toString(entity);
					System.out.println("Encrypted Response====="+content);
					textArea.append("\nEncrypted Response====="+content);

					JSONParser enparser = new JSONParser();  
					JSONObject enjson = (JSONObject) enparser.parse(content);  

					boolean enstatus=(boolean) enjson.get("status");
					//boolean enstatus=false;


					if(enstatus)
					{
						ObjectMapper mapper = new ObjectMapper();
						dobj = mapper.readValue(content, RequestDto.class);
						String decrypt = Encryptor.decrypt(dobj.getEncData());
						System.out.println("Decrypted Response====="+decrypt);
						textArea.append("\nDecrypted Response====="+decrypt);

						JSONParser parser = new JSONParser();  
						JSONObject json = (JSONObject) parser.parse(decrypt);  
						System.out.println(al.size());
						Long status=(Long) json.get("status");
						if(status==1)
						{
							//System.out.println("Inside if statement");
							String INSERT_USERS_SQL = "insert into kcc_iss.\"Batch_Processed_"+fy+"\"" + "  (\"ApplicationId\",\"uniqueId\", \"BatchAckId\", \"ProcessedDate\") VALUES " +
									" (?, ?, ?, CURRENT_DATE);";
							PreparedStatement preparedStatement = c.prepareStatement(INSERT_USERS_SQL);
							Iterator<Applicant> it=al.iterator();
							while ( it.hasNext()) {
								System.out.println("Inside while statement");
								Applicant newApp=it.next();
								preparedStatement.setString(1, newApp.getApplicationId());
								preparedStatement.setString(2, newApp.getUniqueId());
								preparedStatement.setString(3, (String) json.get("batchAckId"));
								preparedStatement.addBatch();
							}

							//long start = System.currentTimeMillis();
							int[] inserted = preparedStatement.executeBatch();
							preparedStatement.close();
							//long end = System.currentTimeMillis();
						}

					}
					else
					{
						//System.out.println("Inside if statement");
						String INSERT_USERS_SQL = "insert into kcc_iss.\"Batch_Processed_"+fy+"\"" + "  (\"ApplicationId\",\"uniqueId\", \"ProcessedDate\") VALUES " +
								" (?,?,  CURRENT_DATE);";
						PreparedStatement preparedStatement = c.prepareStatement(INSERT_USERS_SQL);
						Iterator<Applicant> it=al.iterator();
						while ( it.hasNext()) {
							//System.out.println("Inside while statement");
							Applicant newApp=it.next();
							preparedStatement.setString(1, newApp.getApplicationId());
							preparedStatement.setString(2, newApp.getUniqueId());
							preparedStatement.addBatch();
						}

						//long start = System.currentTimeMillis();
						int[] inserted = preparedStatement.executeBatch();
						preparedStatement.close();
					}
					rs.close();

					stmt.close();

					c.close();
					return "{\"responseCode\":\"200\"}";
					//return decrypt;
				} catch (Exception e) {

					e.printStackTrace();
					return "{\"responseCode\":\"201\"}";
				}
			}
			else
			{
				System.out.println("No Data Available");
				textArea.append("\nNo Data Available");
				
			}
		}
		return "{\"responseCode\":\"200\"}";

	}

	public static String convertToJson(JSONObject vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	public static String convertToJson(RequestDto vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}


}
