package org.crgb.fasalbima.main;


import com.fasterxml.jackson.databind.ObjectMapper;

import java.awt.TextArea;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.Properties;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import org.crgb.fasalbima.common.*;
import org.crgb.fasalbima.dbcom.*;
import org.crgb.fasalbima.obj.*;
import org.crgb.fasalbima.encryption.*;

public class GetBatchStatus {
	CloseableHttpClient httpClient = HttpClients.createDefault();
	public  String  BatchStatus(Properties prop, String fy, TextArea textArea) throws IOException, SQLException {
System.out.println(prop.getProperty("data_by_ack_id_url"));
		String abc = "";
		String def = "";
		BatchStatus dob = new BatchStatus();
		RequestDto dobj = new RequestDto();
		HttpPost postreq = new
				HttpPost(prop.getProperty("data_by_ack_id_url"));

		//https://fasalrin.gov.in/v1/issintegration/databybatchackid

		DBConnection db=new DBConnection();
		Connection c =db.ConnectionString(prop);
		Statement stmt = c.createStatement();

		String sql = "select distinct \"BatchAckId\" from kcc_iss.\"Batch_Processed_"+fy+"\" where \"Status\" isnull and \"BatchAckId\" notnull";
		
		
		
		System.out.println("===="+sql);
		textArea.append(sql+"\n");
		ResultSet rs = stmt.executeQuery( sql );
		
		while(rs.next())
		{
			dob.setBatchAckId(rs.getString("BatchAckId"));

			abc = convertToJson(dob);
			String reqEncrypt = "";
			try {
//				String key = prop.getProperty("key");
//				System.out.println("ddv " + key);
				reqEncrypt = Encryptor.encrypt(abc);
				dobj.setClientId(prop.getProperty("clientId"));
				dobj.setEncData(reqEncrypt);

				def = convertToJson(dobj);

				System.out.println("Req======"+abc);
				textArea.append("Req======"+abc+"\n");

				System.out.println("Request Encrypted===="+def);
				textArea.append("Request Encrypted===="+def+"\n");
				StringEntity input = new StringEntity(def);
				input.setContentType("application/json");
				postreq.setEntity(input);
				//postreq.addHeader("AccessToken", key);
				CloseableHttpResponse res = httpClient.execute(postreq);
				HttpEntity entity = res.getEntity();
				String content = EntityUtils.toString(entity);
				System.out.println("Encrypted Response====="+content);
				textArea.append("Encrypted Response====="+content+"\n");
				JSONParser enparser = new JSONParser();  
				JSONObject enjson = (JSONObject) enparser.parse(content);  
				
				boolean enstatus=(boolean) enjson.get("status");
				if(enstatus)
				{
					ObjectMapper mapper = new ObjectMapper();
					dobj = mapper.readValue(content, RequestDto.class);
					String decrypt = Encryptor.decrypt(dobj.getEncData());
					System.out.println("Decrypted Response====="+decrypt);
					
					textArea.append("Decrypted Response====="+decrypt+"\n");
	
					JSONParser parser = new JSONParser();  
					JSONObject json = (JSONObject) parser.parse(decrypt); 
	
					JSONArray jsonArray =  (JSONArray) json.get("applications") ;
					
					
					//System.out.println(al.size());
					//Long status=(Long) json.get("status");
					System.out.println("Inside if statement");
					String INSERT_USERS_SQL = "update kcc_iss.\"Batch_Processed_"+fy+"\" set \"Status\"=?, error=?,\"farmerId\"=?,\"LoanAppplicationNumber\"=? where \"uniqueId\"=?";
					
					PreparedStatement preparedStatement = c.prepareStatement(INSERT_USERS_SQL);
					for(int i=0;i<jsonArray.size();i++)
					{
						JSONObject appJson = (JSONObject) jsonArray.get(i); 
						Long status=(Long) appJson.get("applicationStatus");
						preparedStatement.setString(1,status.toString());
						//Long status=(Long) appJson.get("applicationStatus");
						if(status==1)
						{
							preparedStatement.setString(2, "");
							preparedStatement.setString(3, (String) appJson.get("farmerId"));
							preparedStatement.setString(4, (String) appJson.get("applicationNumber"));
						}
						else
						{
							preparedStatement.setString(2, (String) appJson.get("errors"));
							preparedStatement.setString(3, "");
							preparedStatement.setString(4, "");
						}
						preparedStatement.setString(5, (String) appJson.get("uniqueId"));
						preparedStatement.addBatch();
	
						//long start = System.currentTimeMillis();
	
						//long end = System.currentTimeMillis();
					}
					int[] inserted = preparedStatement.executeBatch();
					
					
					rs.close();

					stmt.close();

					c.close();
					return "{\"responseCode\":\"200\"}";
				}

				//return decrypt;
			} catch (Exception e) {

				e.printStackTrace();
				JOptionPane.showMessageDialog(null,"Something Went Wrong");
				return "{\"responseCode\":\"201\"}";
			}
		}
		
		
		return "{\"responseCode\":\"200\"}";

	}

	public static String convertToJson(RequestDto vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	public static String convertToJson(BatchStatus vaTac) {
		String jsonString = "";
		ObjectMapper mapper = new ObjectMapper();
		try {
			jsonString = mapper.writeValueAsString(vaTac);
		} catch (Exception e) {
			System.out.printf(e.getMessage());
		}
		return jsonString;
	}

	public static Properties readPropertiesFile(String fileName) throws IOException {
		FileInputStream propFile = null;
		Properties prop = null;
		try {
			propFile = new FileInputStream(fileName);
			prop = new Properties();
			prop.load(propFile);
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException ex) {
			ex.printStackTrace();
		} finally {
			propFile.close();
		}
		return prop;
	}
}


